<?php include('header.php');


$db = db::open();
$query = "SELECT *  from about_us";
$abouts = db::getRecords($query);


?>

<div class='main-content'>
    <div class='page-content'>
        <div class='container-fluid'>
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">

                        <h3 class="text-center text-white my-2">About</h3>
                    </div>
                </div>
            </div>
            <!--end row-->
            <div class="row">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">About Us</li>
                        </ol>

                    </div>
                </div>
            </div>





            <div class='row mt-5'>
                <?php
                if ($abouts != Null) {
                    foreach ($abouts as $about) {
                        $about_image = "./uploads/about/" . $about['about_image'];
                        $about_description = $about['about_description'];
                        $about_short_description = $about['about_short_description'];
                        $about_description = trim($about_description, " \t\n\r");
                        $about_description = trim(preg_replace('/\s+/', ' ', $about_description));
                        $about_description = str_replace("'", "--", $about_description);
                        $about_description = str_replace("&#39;", "--", $about_description);
                        $about_description = str_replace("&#34;;", "__", $about_description);
                        $about_description = str_replace('"', '__', $about_description);
                        ?>
                <div class='col-md-6'>
                    <div class='card' style="height: 95%; width: 100%; ">
                        <img class='card-img-top object-cover h-100' loading="lazy" height="300px"
                            src='<?php echo $about_image ?>' alt='about-image   '>
                        <div class="card-body">
                        <h2 class='my-3'>Short Description</h2>
                        <h4 id="short_description" class='mt-2 fs-5'>
                        <?php echo $about_short_description ?>
                        </h4>
                        </div>
                        <div class='card-footer pt-4 mt-3  d-flex justify-content-around text-center'>
                            <button type='button' class='btn btn-primary waves-effect waves-light btn-xxl float-left'
                                onclick="view_modal('<?php echo $about_image ?>','<?php echo $about_short_description ?>')"><i class='fas fa-eye'></i></button>
                            <button type='button' class='btn btn-success btn-xl  waves-effect waves-light'
                                onclick="edit_modal('<?php echo $about['id']; ?>')"><i class='fas fa-user-edit'>
                                </i></button>
                        </div>
                    </div><!-- end card -->
                </div>



                <div class='col-md-6'>
                    <div class='card' style="height: 95%; width: 100%;">

                        <div class='card-body overflow-hidden' style="height: 450px;">
                            <?php echo $about_description; ?>
                        </div>
                        <div class='card-footer pt-4 mt-3  d-flex justify-content-around text-center'>
                            <button type='button' class='btn btn-primary waves-effect waves-light btn-xxl float-left'
                                onclick="view_description_modal('<?php echo $about_description ?>')"><i
                                    class='fas fa-eye'></i></button>
                            <button type='button' class='btn btn-success btn-xl  waves-effect waves-light'
                                onclick="edit_description_modal('<?php echo $about['id'] ?>','<?php echo $about_description ?>')"><i
                                    class='fas fa-user-edit'> </i></button>

                        </div>
                    </div><!-- end card -->
                </div>
                <?php }
                } ?>

            </div>

        </div>
    </div>



    <div id='view-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true' style='display: none;'>
        <div class='modal-dialog modal-dialog-centered  '>
            <div class='modal-content border-0 border-0'>
                <div class='close d-flex justify-content-between align-items-center  px-4 py-3 '>
                    <h2 class='text-black'>About Image </h2>
                    <button type='button' class='btn-close  mt-n2 opacity-100' data-bs-dismiss='modal'
                        aria-label='Close'></button>
                </div>
                <div class=' modal-body py-3 px-5'>

                    <img class='card-img-top' id="about_image" alt=''>
                    <div class="heading my-4">
                        <h2 class="text-dark">Short D</h2>
                        <h5 class="text-grey mt-3" id="about_short_description" > </h5>
                    </div>

                    <div class='heading my-3 float-end'>
                        <button type='button' data-bs-dismiss="modal"
                            class='btn btn-light waves-effect waves-light btn-lg btn-block'>Close</button>
                    </div>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>


    <div id='view-description-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true'
        style='display: none;'>
        <div class='modal-dialog modal-dialog-centered  '>
            <div class='modal-content border-0 border-0'>
                <div class='close d-flex justify-content-between align-items-center  px-4 py-3 '>
                    <h2 class='text-black'>About Description </h2>
                    <button type='button' class='btn-close  mt-n2 opacity-100' data-bs-dismiss='modal'
                        aria-label='Close'></button>
                </div>
                <div class=' modal-body py-3 px-5'>

                    <div id="view_about_description">

                    </div>

                    <div class='heading my-3 float-end'>
                        <button type='button' data-bs-dismiss="modal"
                            class='btn btn-light waves-effect waves-light btn-lg btn-block'>Close</button>
                    </div>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>


    <div id='edit-modal' class='modal fade' aria-labelledby='edit-modal' aria-hidden='true' style='display: none;'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content border-0'>
                <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                    <h2 class='text-white'>Edit Details</h2>
                    <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                        aria-label='Close'></button>
                </div>
                <div class=' modal-body py-3 px-5'>
                    <form action="action.php" method="post" enctype="multipart/form-data">
                        <div class='heading my-3'>
                            <div class='mb-3 '>
                                <label for='image_about' class='form-label fs-4  '>About Image</label>
                                <input type="file" multiple class="form-control mb-3" name="image_about" />
                            </div>

                            <div class='heading my-3'>
                            <label for="short_description_input" class='my-3 fs-4'>Short Description</label>
<textarea class="form-control" placeholder="Enter Description" name="short_description" id="short_description_input" value="<?php echo $about_short_description ?>" cols="30" rows="10"><?php echo $about_short_description ?></textarea>
                            <div class='mb-3'>
                                    <input type="hidden" id="update_about_id" name="about_update_id">
                                    <div class="d-flex justify-content-between pt-3">
                                        <button type='button' data-bs-dismiss="modal"
                                            class='btn btn-primary w-lg fs-5 me-2'> Close
                                        </button>
                                        <button type='submit' name="update_about"
                                            class='btn btn-success w-lg fs-5'>Update</button>
                                    </div>
                                </div>
                            </div>

                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>
</div>



<div id='edit-description-modal' class='modal fade' aria-labelledby='edit-modal' aria-hidden='true'
    style='display: none;'>
    <div class='modal-dialog modal-dialog-centered modal-xl'>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                <h2 class='text-white'>Edit Details</h2>

                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <form action="action.php" method="post" id="myForm" enctype="multipart/form-data">
                    <div class="card">

                        <div class="card-body">
                            <textarea name="ckdata" class="ckeditor">
                                        <?php echo $about_description; ?>
        </textarea> <!-- end Snow-editor-->
                        </div><!-- end card-body -->
                    </div><!-- end card -->

                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <input type="hidden" name="update_about_id" id="update_about_description">
                            <input type="hidden" name="editorData" id="editorData">
                            <div class="d-flex justify-content-between pt-3">
                                        <button type='button' data-bs-dismiss="modal"
                                            class='btn btn-primary w-lg fs-5 me-2'> Close
                                        </button>
                            <button type='submit' name="update_about_description"
                                class='btn btn-success w-lg fs-5'>Update
                                About</button>
                            </div>
                        </div>
                    </div>

                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
</div>



</div>
</div>
</div>


















<script src="./assets/ckeditor/ckeditor.js"></script>
<!-- JAVASCRIPT -->
<script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
<script src='assets/libs/simplebar/simplebar.min.js'></script>
<script src='assets/libs/node-waves/waves.min.js'></script>
<script src='assets/libs/feather-icons/feather.min.js'></script>
<script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
<script src='assets/js/plugins.js'></script>
<!-- Sweet Alerts js -->
<script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

<!-- Sweet alert init js-->
<script src='assets/js/pages/sweetalerts.init.js'></script>
<!-- calendar min js -->
<script src='assets/libs/fullcalendar/main.min.js'></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- ckeditor -->
<script src="assets/libs/@ckeditor/ckeditor5-build-classic/build/ckeditor.js"></script>

<!-- quill js -->
<script src="assets/libs/quill/quill.min.js"></script>

<!-- init js -->
<script src="assets/js/pages/form-editor.init.js"></script>

<!-- Calendar init -->
<script src='assets/js/pages/calendar.init.js'></script>

<!-- App js -->
<script src='assets/js/app.js'></script>

<script>
function view_modal(about_image,about_short_description) {
    document.getElementById('about_image').src = about_image;
    document.getElementById('about_short_description').innerHTML = about_short_description;
    $("#view-modal").modal('show');
}

function view_description_modal(about_description) {
    document.getElementById('view_about_description').innerHTML = about_description;
    $("#view-description-modal").modal('show');
}

function edit_modal(id) {
    document.getElementById('update_about_id').value = id;
    $("#edit-modal").modal('show');
}

function edit_description_modal(id) {
    document.getElementById('update_about_description').value = id;

    $("#edit-description-modal").modal('show');
}
</script>
<script>
const urlParams = new URLSearchParams(window.location.search);


if (urlParams.get('status') === '1') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4>about Added</h4><p class="text-muted mx-4 mb-0">about Have Been Successfully Added</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}

if (urlParams.get('status') === '2') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>about Deleted</h4><p class="text-muted mx-4 mb-0">about Have Been Successfully Deleted</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
if (urlParams.get('status') === '3') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>About  Updated</h4><p class="text-muted mx-4 mb-0">About Have Been Successfully Updated</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
</script>
<script>
ClassicEditor
    .create(document.querySelector('#editor'))
    .catch(error => {
        console.error(error);
    });
</script>

</body>

</html>