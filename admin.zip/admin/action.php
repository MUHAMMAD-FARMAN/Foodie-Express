<?php
session_start();

require_once("database.php");

// Uer Login Actions

if (isset($_POST['sign-up'])) {
    $db = db::open();

    $full_name = $db->real_escape_string($_POST['full_name']);
    $user_email = $db->real_escape_string($_POST['email']);
    $phone = $db->real_escape_string($_POST['phone']);
    $password = $db->real_escape_string($_POST['password']);
    $confirm_password = $db->real_escape_string($_POST['confirm_password']);
    $address = $db->real_escape_string($_POST['address']);
    $city = $db->real_escape_string($_POST['city']);
    $country = $db->real_escape_string($_POST['country']);
    $postal_code = $db->real_escape_string($_POST['postal_code']);

    // Check if the email already exists in the database
    $query = "SELECT email FROM user_login WHERE email = '$user_email'";
    $user_mail = db::getRecord($query);

    if (!empty($user_mail)) {
        // Email already exists
        $status = 1;
        header("Location: ../register.php?status=" . $status);
        exit();
    }

    if ($password == $confirm_password) {
        $options = ['cost' => 12];
        $hash_password = password_hash($password, PASSWORD_DEFAULT, $options);
    } else {
        // Passwords don't match
        $status = 2;
        header("Location: ../register.php?status=" . $status);
        exit();
    }

    // Insert new user data into the database
    $query = "INSERT INTO user_login (full_name, email, phone, password, address, city, country, postal_code) 
              VALUES ('$full_name', '$user_email', '$phone', '$hash_password', '$address', '$city', '$country', '$postal_code')";
    $insert = db::query($query);

    if ($insert === false) {
        // Check for any SQL errors
        $status = "Error: " . $db->error; // or use the appropriate function for your database class
        $status = 4;
        header("Location: ../register.php?status=" . $status);
        exit();
    }

    // Registration successful
    $status = 3;
    header("Location: ../login.php?status=" . $status);
}

if (isset($_POST['update_user_details'])) {
    $db = db::open();

    $full_name = $db->real_escape_string($_POST['full_name']);
    $user_email = $db->real_escape_string($_POST['email']);
    $phone = $db->real_escape_string($_POST['phone']);
    $password = $db->real_escape_string($_POST['password']);
    $confirm_password = $db->real_escape_string($_POST['confirm_password']);
    $address = $db->real_escape_string($_POST['address']);
    $city = $db->real_escape_string($_POST['city']);
    $country = $db->real_escape_string($_POST['country']);
    $postal_code = $db->real_escape_string($_POST['postal_code']);

    

    // Insert new user data into the database
  // Update user data in the database
  $query = "UPDATE user_login SET full_name = '$full_name', phone = '$phone', address = '$address', city = '$city', country = '$country', postal_code = '$postal_code' WHERE email = '$user_email'";
  $update = db::query($query);

    if ($update === false) {
        // Check for any SQL errors
        $status = "Error: " . $db->error; // or use the appropriate function for your database class
        $status = 4;
        header("Location: ../dashboard.php?status=" . $status);
        exit();
    }

    // Registration successful
    $status = 3;
    header("Location: ../dashboard.php?status=" . $status);
}




if (isset($_POST['user_login'])) {
    $db = db::open();
    $email = $db->real_escape_string($_POST['email']);
    $password = $db->real_escape_string($_POST['password']);
    $query = "SELECT * from user_login where email='$email'";
    $user_login = db::getRecord($query);

    if ($user_login != NULL) {
        if (password_verify($password, $user_login['password'])) {
            // User authentication successful
            $status = "4";
            $_SESSION['user_email'] = $email;
             $user_id = $_SESSION['user_id']; 
             $query = "UPDATE cart_temp SET user_id='$email' WHERE user_id = '$user_id'";
             $update = db::query($query);
            header("Location: ../index.php?status=" . $status);
            exit();
        } else {
            // Incorrect password
            $status = "1";
            header("Location: ../login.php?status=" . $status);
            exit();
        }
    } else {
        // User not found
        $status = "3";
        header("Location: ../login.php?status=" . $status);
        exit();
    }
}



if (isset($_POST['user_change_password'])) {
    $db = db::open();

    $old_password = $db->real_escape_string($_POST['old_password']);
    $new_password = $db->real_escape_string($_POST['new_password']);
    $confirm_password = $db->real_escape_string($_POST['confirm_new_password']);
    $id = $db->real_escape_string($_POST['id']);
    $query = "SELECT password from user_login WHERE email = '$id'";
    $user_login = db::getRecord($query);

    if (password_verify($old_password, $user_login['password'])) {

        if ($new_password == $confirm_password) {
            $options = ['cost' => 12];
            $hash_password = password_hash($new_password, PASSWORD_DEFAULT, $options);

            $query = "UPDATE user_login SET  password='$hash_password' WHERE email = '$id'";
            $update = db::query($query);
            $status = 3;
            header("Location: ../index.php?status=" . $status);

        } else {
            $status = 2;
            header("Location: ../dashboard.php?status=" . $status);
        }

    } else {
        $status = 4;
        header("Location: ../dashboard.php?status=" . $status);
    }
}


if (isset($_POST['user_forget_password'])) {
    $email = $db->real_escape_string($_POST['email']);
    $query = "SELECT * from user_login WHERE email = '$email'";
    $user_login = db::getRecord($query);
    if(!$user_login) {
        $status = 4;
        header("Location: ../forgot_password.php?email=$email&status=$status");
    } 
}



if (isset($_POST['user_logout'])) {
    unset($_SESSION['user_email']);
    $status = 4;
    header("Location: ../login.php?status=" . $status);
}

if (isset($_POST['user_verify_code'])) {
    $db = db::open();
    $user_code = $_POST['code'];
    $email = $_POST['email'];

    $query = "SELECT * FROM verify_code WHERE email='$email' ORDER BY id DESC";
    $verification = db::getRecord($query);

    if ($user_code == $verification['code']) {
        $verified = 1;
        $query = "UPDATE user_login SET  verified = '$verified'  WHERE email = '$email'";
        $update = db::query($query);
        $query = "DELETE from verify_code WHERE code = '$user_code'";
        $delete_code = db::query($query);
        if($delete_code){
               $status = 7;
        header("Location: ../login.php?status=" . $status);
        }
     
    } else {
        $status = 4;
        header("Location: ../verify-code.php?email=$email&status=$status");

    }
}
if (isset($_POST['user_verify_password'])) {
    $db = db::open();
    $user_code = $_POST['code'];
    $email = $_POST['email'];

    $query = "SELECT * FROM verify_code WHERE email='$email' ORDER BY id DESC";
    $verification = db::getRecord($query);

    if ($user_code == $verification['code']) {
        $status = 2;
        header("Location: ../reset-password.php?email=$email&status=$status&code=$user_code");
    } else {
        $status = 4;
        header("Location: ../verify-password.php?email=$email&status=$status");
    }
}






if (isset($_POST['user_reset_password'])) {
    $db = db::open();
    $new_password = $db->real_escape_string($_POST['password']);
    $confirm_new_password = $db->real_escape_string($_POST['confirm_password']);
    $email = $db->real_escape_string($_POST['email']);
    $user_code = $_POST['code'];
    $query = "SELECT * from user_login WHERE email = '$email'";
    $user_login = db::getRecord($query);
    if ($new_password == $confirm_new_password) {
        $options = ['cost' => 12];
        $hash_password = password_hash($new_password, PASSWORD_DEFAULT, $options);
        $query = "UPDATE user_login SET  password='$hash_password' WHERE email = '$email'";
        $update = db::query($query);
        if($update){
            $query = "DELETE from verify_code WHERE code = '$user_code'";
            $delete_code = db::query($query);
            $status = 5;
            header("Location: ../login.php?status=" . $status);
            exit();
        }
    } else {
        $email = $db->real_escape_string($_POST['email']);
        $status = 2;
        header("Location: ../reset-password.php?email=$email&status=$status");
    }
}
    




if (isset($_POST['check_login'])) {

    $db = db::open();
    if(isset($_SESSION['user_email'])){
        $user_email = $_SESSION['user_email'];

        $query = "SELECT * FROM cart_temp WHERE user_id = '$user_email'";
        $cart = db::getRecords($query);
        $order_id = rand(10, 100000);
        $query = "SELECT * from orders WHERE order_id='$order_id'";
        $order = db::getRecord($query);
         if ($order != NULL) {
           while ($order != NULL) {
            $order_id = rand(10, 100000);
            $query = "SELECT * from orders WHERE order_id='$order_id'";
            $order = db::getRecord($query);
        }}


        $size = NULL;

        if (is_array($cart)) {
            $size = sizeof($cart);
        }

        $query = "SELECT * FROM user_login WHERE email = '$user_email'";
        $user_details = db::getRecord($query);
        $full_name = $user_details['full_name'];
        $address = $user_details['address'];
        $city = $user_details['city'];
        $country = $user_details['country'];
        $zip = $user_details['postal_code'];
        $email = $user_details['email'];
        $phone = $user_details['phone'];
        $total_products = $size;
        $total_cart_bill = 0; 

        if ($cart != null) {
            foreach ($cart as $cart2) {
    
    
                $product_id = $cart2['product_id'];
    
                $quantity = $cart2['quantity'];
    
                $query = "SELECT * from products where id='$product_id'";
                $product = db::getRecord($query);
                $product_name  = $product['product_title'];
                $product_price = $product['product_price'];
                $total_price = $product_price * $quantity;
                $total_bill += $total_price;

                $query = "INSERT into order_details (order_id,product_id,quantity,price,total_price) VALUES ('$order_id','$product_id','$quantity','$product_price','$total_price')";
                $insert = db::query($query);
            }
        }

        $query = "INSERT into orders (order_id,full_name,email,phone,address,postal_code,city,country,total_products,total_bill)
        VALUES ('$order_id','$full_name','$email','$phone','$address','$zip','$city','$country','$size','$total_bill')";
        $insert = db::query($query);
        if($insert) {
            
            $query = "DELETE from cart_temp where user_id='$email'";
            $del = db::query($query);
        $status = 2;
        header("Location: ../final-message.php?status=$status"); } 
    } else {
        $status = 6;
        header("Location: ../login.php?status=$status");
    }

}


// Admin login Actions



if (isset($_POST['login'])) {
    $db = db::open();
    $email = $db->real_escape_string($_POST['email']);
    $password = $db->real_escape_string($_POST['password']);
    $query = "SELECT * from admins where  email='$email'";
    $admin = db::getRecord($query);


    if ($admin != NULL) {
        if (password_verify($password, $admin['password'])) {
            $status = "4";
            $_SESSION["admin_email"] = $admin['email'];
            header("Location: dashboard.php?status=" . $status);
        } else {
            $status = "1";
            header("Location: sign-in.php?status=" . $status);
        }
    } else {
        $status = "3";
        header("Location: sign-in.php?status=" . $status);
    }
}



if (isset($_POST['change_password'])) {
    $db = db::open();

    $old_password = $db->real_escape_string($_POST['old_password']);
    $new_password = $db->real_escape_string($_POST['new_password']);
    $confirm_password = $db->real_escape_string($_POST['confirm_new_password']);
    $id = $db->real_escape_string($_POST['id']);
    $query = "SELECT password from admins WHERE email = '$id'";
    $admin = db::getRecord($query);
     if (password_verify($old_password, $admin['password'])) {
        if ($new_password == $confirm_password) {
            $options = ['cost' => 12];
            $hash_password = password_hash($new_password, PASSWORD_DEFAULT, $options);
            $query = "UPDATE admins SET  password='$hash_password' WHERE email = '$id'";
            $update = db::query($query);
            $status = 3;
            header("Location: dashboard.php?status=" . $status);
        } else {
            $status = 2;
            header("Location: profile.php?status=" . $status);
        }

    } else {
        $status = 4;
        header("Location: profile.php?status=" . $status);
    }
}



if (isset($_POST['reset_password'])) {
    $db = db::open();

    $new_password = $db->real_escape_string($_POST['new_password']);
    $confirm_new_password = $db->real_escape_string($_POST['confirm_new_password']);
    $email = $db->real_escape_string($_POST['email']);

    $query = "SELECT * from admins WHERE email = '$email'";
    $admin = db::getRecord($query);

    if ($new_password == $confirm_new_password) {
        $options = ['cost' => 12];
        $hash_password = password_hash($new_password, PASSWORD_DEFAULT, $options);
        $query = "UPDATE admins SET  password='$hash_password' WHERE email = '$email'";
        $update = db::query($query);
        $status = 5;
        header("Location: sign-in.php?status=" . $status);

    } else {
        $status = 2;
        header("Location: profile.php?status=" . $status);
    }

}



if (isset($_POST['forget_password'])) {
    $email = $db->real_escape_string($_POST['email']);
    $query = "SELECT * from admins WHERE email = '$email'";
    $admin = db::getRecord($query);
    if(!$admin) {
        $status = 4;
        header("Location: forget-password.php.php?email=$email&status=$status");
    } 
   
}


if (isset($_POST['verify_code'])) {
    $db = db::open();
    $user_code = $_POST['code'];
    $email = $_POST['email'];

    $query = "SELECT * FROM verify_code WHERE email='$email' ORDER BY id DESC";
    $verification = db::getRecord($query);

    if ($user_code == $verification['code']) {
        header("Location: reset-password.php?email=" . $email);
    } else {
        $status = 4;
        header("Location: verify-code.php?email=$email&status=$status");

    }
}

if (isset($_POST['logout'])) {
    unset($_SESSION['admin_email']);
    $status = 4;
    header("Location: sign-in.php?status=" . $status);
}





if (isset($_POST['update_details'])) {
    $db = db::open();
    $email = $_SESSION['admin_email'];
    $first_name = $db->real_escape_string($_POST['fname']);
    $last_name = $db->real_escape_string($_POST['lname']);
    $user_email = $db->real_escape_string($_POST['email']);
    $phone = $db->real_escape_string($_POST['phone']);
    $country = $db->real_escape_string($_POST['country']);


    $target_dir = "uploads/profile/";
    $filename = $_FILES["admin_profile"]["name"] ?? NULL;
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $randomNumber = mt_rand(100000, 999999);
    $target_file = $target_dir . $randomNumber . "_" . $filename;
    $uploadOk = 1;
    $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if ($filename != NULL) {

        $email = $_SESSION['admin_email'];
        // Retrieve existing image name from the database
        $query = "SELECT image_name FROM admins WHERE email = '$email'";
        $profile_image = db::getRecord($query);
        $old_image_name = $profile_image['image_name'];

        // Delete the old image file from the uploads folder
        $old_image_path = $target_dir . $old_image_name;
        $old_image_name = glob($target_dir . $old_image_name); // Get all files in the directory    
        foreach ($old_image_name as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }

        // Check if file already exists
        while (file_exists($target_file)) {
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . $randomNumber . "_" . $filename;
        }
        // Check if file is an image
        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
            $uploadOk = 0;
        } else {
            echo "File is an image - " . $imageFileType . ".";
        }

        // Check file size (example: 500 KB)
        $fileSizeKB = $_FILES["admin_profile"]["size"] / 90048;
        $maxFileSizeKB = 900048;
        if ($fileSizeKB > $maxFileSizeKB) {
            echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Attempt to move the uploaded file
            if (move_uploaded_file($_FILES["admin_profile"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["admin_profile"]["name"])) . " has been uploaded.";

                // Update the image from  the database
                $imageName = $randomNumber . "_" . $filename;
                $query = "UPDATE admins SET image_name='$imageName' WHERE email = '$email'";
                $update = db::query($query);
            }
        }
    }

    $query = "UPDATE admins SET first_name='$first_name', last_name='$last_name', email='$user_email', phone='$phone', country='$country' WHERE email = '$email'";
    $update = db::query($query);
    $_SESSION['admin_email'] = $user_email;
    $status = 4;
    header("Location: profile.php?status=" . $status);

}





if (isset($_POST['update_logo'])) {
    
    $db = db::open();
    $target_dir = "uploads/logo/";
    $filename = $_FILES["logo"]["name"] ?? NULL;
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $randomNumber = mt_rand(100000, 999999);
    $target_file = $target_dir . $randomNumber . "_" . $filename;
    $uploadOk = 1;
    $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if ($filename != NULL) {

        // Retrieve existing image name from the database
        $query = "SELECT logo_name from logo WHERE id='1'";
        $profile_image = db::getRecord($query);
        $old_image_name = $profile_image['logo_name'];

        // Delete the old image file from the uploads folder
        $old_image_path = $target_dir . $old_image_name;
        $old_image_name = glob($target_dir . $old_image_name); // Get all files in the directory    
        foreach ($old_image_name as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }

        // Check if file already exists
        while (file_exists($target_file)) {
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . $randomNumber . "_" . $filename;
        }

        // Convert the image to PNG
        $new_image_name = "logo.png";
        $target_file = $target_dir . $randomNumber . "_" . $new_image_name;
        $imageFileType = "png";

        // Check if file is an image
        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
            $uploadOk = 0;
        } else {
            echo "File is an image - " . $imageFileType . ".";
        }

        // Check file size (example: 500 KB)
        $fileSizeKB = $_FILES["logo"]["size"] / 90048;
        $maxFileSizeKB = 900048;
        if ($fileSizeKB > $maxFileSizeKB) {
            echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Attempt to move the uploaded file
            if (move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["logo"]["name"])) . " has been uploaded.";

                // Update the image from  the database
                $imageName = $randomNumber . "_" . $new_image_name;
                $query = "UPDATE logo SET logo_name='$imageName' WHERE id = '1'";
                $update = db::query($query);
                $status = 4;
                header("Location: logo.php?status=" . $status);
            }
        }
    }
}


// if (isset($_POST['add-category'])) {

//     $db = db::open();
//     $category_title = $db->real_escape_string($_POST['category_title']);
//     $category_description = $db->real_escape_string($_POST['category_description']);




//     $target_dir = "uploads/categories/";
//     $filename = $_FILES["category_image"]["name"];
//     $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
//     $randomNumber = mt_rand(100000, 999999);
//     $target_file = $target_dir . $randomNumber . "_" . $filename;
//     $uploadOk = 1;
//     $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
//     $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

//     // Check if file already exists
//     while (file_exists($target_file)) {
//         $randomNumber = mt_rand(100000, 999999);
//         $target_file = $target_dir . $randomNumber . "_" . $filename;
//     }
//     // Check if file is an image
//     if (!in_array($imageFileType, $allowedExtensions)) {
//         echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
//         $uploadOk = 0;
//     } else {
//         echo "File is an image - " . $imageFileType . ".";
//     }

//     // Check file size (example: 500 KB)
//     $fileSizeKB = $_FILES["category_image"]["size"] / 1024;
//     $maxFileSizeKB = 500 * 1024;
//     if ($fileSizeKB > $maxFileSizeKB) {
//         echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
//         $uploadOk = 0;
//     }

//     // Check if $uploadOk is set to 0 by an error
//     if ($uploadOk == 0) {
//         echo "Sorry, your file was not uploaded.";
//     } else {
//         // Attempt to move the uploaded file
//         if (move_uploaded_file($_FILES["category_image"]["tmp_name"], $target_file)) {
//             echo "The file " . htmlspecialchars(basename($_FILES["category_image"]["name"])) . " has been uploaded.";

//             // Insert the image name into the database
//             $imageName = $randomNumber . "_" . $filename;
//             $query = "INSERT into categories (title,description,image_name) VALUES('$category_title','$category_description','$imageName')";
//             $insert = db::query($query);
//             $status = 1;
//             header("Location: categories.php?status=" . $status);
//         } else {
//             $status = 2;
//             header("Location: categories.php?status=" . $status);
//         }
//     }
// }






if (isset($_POST['add-category'])) {

    $db = db::open();
    $category_title = $db->real_escape_string($_POST['category_title']);
    $query = "INSERT into categories (title) VALUES('$category_title')";
    $insert = db::query($query);
    if(!$insert) {
        $status = 5;
        header("Location: categories.php?status=" . $status);
    } else {
        $status = 1;
        header("Location: categories.php?status=" . $status);
    }
  

}


if (isset($_POST['update_category'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['id']);
    $category_title = $db->real_escape_string($_POST['category_title']);
    $query = "UPDATE categories SET title='$category_title' WHERE id = '$id'";
    $update_title = db::query($query);
    if(!$update_title) {
        $status = 2;
        header("Location: categories.php?status=" . $status);
    } else {
        $status = 3;
        header("Location: categories.php?status=" . $status);
    }
  
}


// if (isset($_POST['update_category'])) {
//     $db = db::open();
//     $id = $db->real_escape_string($_POST['id']);
//     $category_title = $db->real_escape_string($_POST['category_title']);
//     $category_description = $db->real_escape_string($_POST['category_description']);

//     $target_dir = "uploads/categories/";
//     $filename = $_FILES["category_image"]["name"] ?? NULL;
//     $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
//     $randomNumber = mt_rand(100000, 999999);
//     $target_file = $target_dir . $randomNumber . "_" . $filename;
//     $uploadOk = 1;
//     $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
//     $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

//     if ($filename != NULL) {

//         // Retrieve existing image name from the database
//         $query = "SELECT image_name FROM categories WHERE id = '$id'";
//         $category = db::getRecord($query);
//         $old_image_name = $category['image_name'];

//         // Delete the old image file from the uploads folder
//         $old_image_path = $target_dir . $old_image_name;
//         $old_image_name = glob($target_dir . $old_image_name); // Get all files in the directory    
//         foreach ($old_image_name as $file) {
//             if (is_file($file)) {
//                 unlink($file); // Delete the file
//             }
//         }

//         // Check if file already exists
//         while (file_exists($target_file)) {
//             $randomNumber = mt_rand(100000, 999999);
//             $target_file = $target_dir . $randomNumber . "_" . $filename;
//         }
//         // Check if file is an image
//         if (!in_array($imageFileType, $allowedExtensions)) {
//             echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
//             $uploadOk = 0;
//         } else {
//             echo "File is an image - " . $imageFileType . ".";
//         }

//         // Check file size (example: 500 KB)
//         $fileSizeKB = $_FILES["category_image"]["size"] / 90048;
//         $maxFileSizeKB = 900048;
//         if ($fileSizeKB > $maxFileSizeKB) {
//             echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
//             $uploadOk = 0;
//         }

//         // Check if $uploadOk is set to 0 by an error
//         if ($uploadOk == 0) {
//             echo "Sorry, your file was not uploaded.";
//         } else {
//             // Attempt to move the uploaded file
//             if (move_uploaded_file($_FILES["category_image"]["tmp_name"], $target_file)) {
//                 echo "The file " . htmlspecialchars(basename($_FILES["category_image"]["name"])) . " has been uploaded.";

//                 // Update the image from  the database
//                 $imageName = $randomNumber . "_" . $filename;
//                 $query = "UPDATE categories SET image_name='$imageName' WHERE id = '$id'";
//                 $update = db::query($query);
//                 $status = 3;
//                 header("Location: categories.php?status=" . $status);
//             }
//         }
//     }


//     $query = "UPDATE categories SET title='$category_title',description='$category_description' WHERE id = '$id'";
//     $update_title = db::query($query);
//     $status = 3;
//     header("Location: categories.php?status=" . $status);
// }
// delete category from categories

if (isset($_POST['delete_category'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['category_id']);
    $query = "SELECT * FROM categories WHERE id = '$id'";
    $category = db::getRecord($query);


    $query = "SELECT * from products where category_id='$id'";
    $products = db::getRecords($query);

    foreach ($products as $product) {
        $product_id = $product['id'];
        $query = "SELECT * FROM product_images WHERE product_id = '$product_id'";
        $product_images = db::getRecords($query);
        $old_image_names = [];

        foreach ($product_images as $product_image) {
            $old_image_names[] = $product_image['product_image_name'];
        }

        // Delete the old image files from the uploads folder
        foreach ($old_image_names as $old_image_name) {
            $target_dir = "uploads/products/";

            $old_image_path = $target_dir . $old_image_name;
            $old_image_files = glob($old_image_path); // Get all files matching the path

            foreach ($old_image_files as $file) {
                if (is_file($file)) {
                    unlink($file); // Delete the file
                }
            }
        }
        // Delete the images from the database
        $query = "DELETE FROM product_images WHERE product_id = '$product_id'";
        $delete = db::query($query);
        $query = "DELETE FROM products WHERE id = '$product_id'";
        $delete = db::query($query);
    }

    if (!empty($category)) {
        $targetDir = "uploads/categories/";
        $image_name = $category['image_name'];
        $files = glob($targetDir . $image_name); // Get all files in the directory

        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }
    }

    $query = "DELETE FROM sub_categories WHERE category_id = '$id'";
    $delete = db::query($query);

    $query = "DELETE FROM categories WHERE id = '$id'";
    $delete = db::query($query);
    $status = '2';
    header("Location: categories.php?status=" . $status);
}




if (isset($_POST['add_sub_category'])) {

    $db = db::open();
    $category_title = $db->real_escape_string($_POST['sub_category_title']);
    $category_id = $db->real_escape_string($_POST['sub_category_id']);

            $query = "INSERT into sub_categories (category_id,title) VALUES('$category_id','$category_title')";
            $insert = db::query($query);
            $status = 1;
            header("Location: sub-categories.php?status=" . $status);   
}



if (isset($_POST['update_sub_category'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['id']);
    $category_id = $db->real_escape_string($_POST['update_select_id']);
    $category_title = $db->real_escape_string($_POST['title']);


    $query = "UPDATE sub_categories SET category_id='$category_id', title='$category_title' WHERE id = '$id'";
    $update_title = db::query($query);
    $status = 3;
    header("Location: sub-categories.php?status=" . $status);
}
// delete category from categories

if (isset($_POST['delete_sub_category'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['sub_category_id']);
    $query = "SELECT * FROM sub_categories WHERE id = '$id'";
    $sub_category = db::getRecord($query);
    $query = "SELECT * from products where sub_category='$id'";
    $products = db::getRecords($query);

    foreach ($products as $product) {
        $product_id = $product['id'];
        $query = "SELECT * FROM product_images WHERE product_id = '$product_id'";
        $product_images = db::getRecords($query);
        $old_image_names = [];

        foreach ($product_images as $product_image) {
            $old_image_names[] = $product_image['product_image_name'];
        }

        // Delete the old image files from the uploads folder
        foreach ($old_image_names as $old_image_name) {
            $target_dir = "uploads/products/";

            $old_image_path = $target_dir . $old_image_name;
            $old_image_files = glob($old_image_path); // Get all files matching the path

            foreach ($old_image_files as $file) {
                if (is_file($file)) {
                    unlink($file); // Delete the file
                }
            }
        }
        // Delete the images from the database
        $query = "DELETE FROM product_images WHERE product_id = '$product_id'";
        $delete = db::query($query);
        $query = "DELETE FROM products WHERE id = '$product_id'";
        $delete = db::query($query);
    }

    if (!empty($sub_category)) {
        $targetDir = "uploads/categories/";
        $image_name = $sub_category['image_name'];
        $files = glob($targetDir . $image_name); // Get all files in the directory

        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }
    }


    $query = "DELETE FROM sub_categories WHERE id = '$id'";
    $delete = db::query($query);
    $status = '2';
    header("Location: sub-categories.php?status=" . $status);
}



if (isset($_POST['add-banner'])) {

    $db = db::open();
    $banner_title = $db->real_escape_string($_POST['banner-title']);
    $banner_description = $db->real_escape_string($_POST['banner_description']);



    $target_dir = "uploads/banners/";
    $filename = $_FILES["banner-image"]["name"];
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $randomNumber = mt_rand(100000, 999999);
    $target_file = $target_dir . $randomNumber . "_" . $filename;
    $uploadOk = 1;
    $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file already exists
    while (file_exists($target_file)) {
        $randomNumber = mt_rand(100000, 999999);
        $target_file = $target_dir . $randomNumber . "_" . $filename;
    }
    // Check if file is an image
    if (!in_array($imageFileType, $allowedExtensions)) {
        echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
        $uploadOk = 0;
    } else {
        echo "File is an image - " . $imageFileType . ".";
    }

    // Check file size (example: 500 KB)
    $fileSizeKB = $_FILES["banner-image"]["size"] / 29248;
    $maxFileSizeKB = 29248;
    if ($fileSizeKB > $maxFileSizeKB) {
        echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // Attempt to move the uploaded file
        if (move_uploaded_file($_FILES["banner-image"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["banner-image"]["name"])) . " has been uploaded.";

            // Insert the image name into the database
            $imageName = $randomNumber . "_" . $filename;
            echo "banner";
            $banner = "INSERT into banners (banner_title,image_name,banner_description) VALUES('$banner_title','$imageName', '$banner_description')";
            $insert = db::query($banner);
            $status = 1;
            header("Location: banner.php?status=" . $status);
        } else {
            $status = 2;
            header("Location: banner.php?status=" . $status);
        }
    }
}

if (isset($_POST['delete-banner'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['banner-id']);
    $banner_title = $db->real_escape_string($_POST['banner_title']);
    $query = "SELECT image_name FROM banners WHERE id = '$id'";
    $banner = db::getRecord($query);

    if (!empty($banner)) {
        $targetDir = "uploads/banners/";
        $image_name = $banner['image_name'];
        $files = glob($targetDir . $image_name); // Get all files in the directory

        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }
    }


    $query = "DELETE FROM banners WHERE id = '$id'";
    $delete = db::query($query);
    $status = '2';
    header("Location: banner.php?status=" . $status);
}

if (isset($_POST['update-banner'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['id_banner']);
    $banner_title = $db->real_escape_string($_POST['title_banner']);
    $banner_description = $db->real_escape_string($_POST['banner_description']);

    $target_dir = "uploads/banners/";
    $filename = $_FILES["image_banner"]["name"] ?? NULL;
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $randomNumber = mt_rand(100000, 999999);
    $target_file = $target_dir . $randomNumber . "_" . $filename;
    $uploadOk = 1;
    $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if ($filename != NULL) {

        // Retrieve existing image name from the database
        $query = "SELECT image_name FROM banners WHERE id = '$id'";
        $banner = db::getRecord($query);
        $old_image_name = $banner['image_name'];

        // Delete the old image file from the uploads folder
        $old_image_path = $target_dir . $old_image_name;
        $old_image_name = glob($target_dir . $old_image_name); // Get all files in the directory    
        foreach ($old_image_name as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }

        // Check if file already exists
        while (file_exists($target_file)) {
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . $randomNumber . "_" . $filename;
        }
        // Check if file is an image
        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
            $uploadOk = 0;
        } else {
            echo "File is an image - " . $imageFileType . ".";
        }

        // Check file size (example: 500 KB)
        $fileSizeKB = $_FILES["image_banner"]["size"] / 90048;
        $maxFileSizeKB = 900048;
        if ($fileSizeKB > $maxFileSizeKB) {
            echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Attempt to move the uploaded file
            if (move_uploaded_file($_FILES["image_banner"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["image_banner"]["name"])) . " has been uploaded.";

                // Update the image from  the database
                $imageName = $randomNumber . "_" . $filename;
                $query = "UPDATE banners SET image_name='$imageName' WHERE id = '$id'";
                $update = db::query($query);
                $status = 2;
                header("Location: banner.php?status=" . $status);
            }
        }
    }




    $query = "UPDATE banners SET banner_title='$banner_title',banner_description='$banner_description' WHERE id = '$id'";
    $update_title = db::query($query);
    $status = 3;
    header("Location: banner.php?status=" . $status);
}










if (isset($_POST['update_about'])) {
    $db = db::open();
    $id = $db->real_escape_string($_POST['about_update_id']);
    $short_description = $db->real_escape_string($_POST['short_description']);



    $target_dir = "uploads/about/";
    $filename = $_FILES["image_about"]["name"] ?? NULL;
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $randomNumber = mt_rand(100000, 999999);
    $target_file = $target_dir . $randomNumber . "_" . $filename;
    $uploadOk = 1;
    $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if(!empty($short_description)) {
        $query = "UPDATE about_us SET about_short_description='$short_description' WHERE id = '$id'";
        $update = db::query($query);
        if($filename == NULL){
            $status = 3;
            header("Location: about.php?status=" . $status);
        }
    }
    if ($filename != NULL) {

        // Retrieve existing image name from the database
        $query = "SELECT about_image FROM about_us WHERE id = '$id'";
        $about = db::getRecord($query);
        $old_image_name = $about['about_image'];

        // Delete the old image file from the uploads folder
        $old_image_path = $target_dir . $old_image_name;
        $old_image_name = glob($target_dir . $old_image_name); // Get all files in the directory    
        foreach ($old_image_name as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }

        // Check if file already exists
        while (file_exists($target_file)) {
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . $randomNumber . "_" . $filename;
        }
        // Check if file is an image
        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
            $uploadOk = 0;
        } else {
            echo "File is an image - " . $imageFileType . ".";
        }

        // Check file size (example: 500 KB)
        $fileSizeKB = $_FILES["image_about"]["size"] / 90048;
        $maxFileSizeKB = 900048;
        if ($fileSizeKB > $maxFileSizeKB) {
            echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Attempt to move the uploaded file
            if (move_uploaded_file($_FILES["image_about"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["image_about"]["name"])) . " has been uploaded.";

                // Update the image from  the database
                $imageName = $randomNumber . "_" . $filename;
                $query = "UPDATE about_us SET about_image='$imageName' WHERE id = '$id'";
                $update = db::query($query);
                $status = 3;
                header("Location: about.php?status=" . $status);
            }
        }
    }
}



if (isset($_POST['update_about_description'])) {
    $id = $_POST['update_about_id'];
    $editorData = $_POST['ckdata'];
    $query = "UPDATE about_us SET about_description='$editorData' WHERE id = '$id'";
    $update = db::query($query);
    $status = 3;
    header("Location: about.php?status=" . $status);

}






if (isset($_POST['add-product'])) {
    // Open database connection
    $db = db::open();
    // Sanitize and escape user input
    $product_title = $db->real_escape_string($_POST['product_name']);
    $product_category_id = $db->real_escape_string($_POST['category_id']);
    $product_description = $db->real_escape_string($_POST['product_description']);
    $product_description_short = $db->real_escape_string($_POST['product_description_short']);
    $product_price = $db->real_escape_string($_POST['product_price']);
    $product_stock = $db->real_escape_string($_POST['product_stock']);
    $product_sub_category_id = $db->real_escape_string($_POST['add_sub_category_id']);
 

    $product_feature = $db->real_escape_string($_POST['product_feature']);
    $product_stock = isset($_POST['product_stock']) ? $_POST['product_stock'] : 0;
    $product_feature = isset($_POST['product_feature']) ? $_POST['product_feature'] : 0;

 

    // Insert product into the database
    $product = "INSERT INTO products (product_description, product_description_short, product_title, product_price, product_stock, product_feature,category_id,sub_category) VALUES ('$product_description', '$product_description_short', '$product_title', '$product_price', '$product_stock', '$product_feature','$product_category_id','$product_sub_category_id')";
    $insert = db::query($product);



    $query = "SELECT MAX(id) FROM products";
    $id = db::getRecord($query);
    $max_id = $id['MAX(id)'];

    // Process uploaded images
    $fileNames = $_FILES["product_images"]["name"];

    // Convert to an array if only a single file is uploaded
    if (!is_array($fileNames)) {
        $fileNames = array($fileNames);
    }


    foreach ($fileNames as $key => $name) {
        // Set target directory and file path
        $target_dir = "uploads/products/";
        $filename = $name;
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $randomNumber = mt_rand(100000, 999999);
        $target_file = $target_dir . $randomNumber . "_" . $filename;

        // Check if file already exists
        while (file_exists($target_file)) {
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . "_" . $randomNumber . "_" . $filename;
        }

        // Check if file is an image
        $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (!in_array($imageFileType, $allowedExtensions)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed.";
            continue; // Skip this file and proceed to the next iteration
        }

        $fileSizeKB = $_FILES["product_images"]["size"][$key] / 1024;
        $maxFileSizeKB = 500 * 1024;
        if ($fileSizeKB > $maxFileSizeKB) {
            echo "Sorry, your file is too large. Maximum file size is " . $maxFileSizeKB . " KB.";
            continue; // Skip this file and proceed to the next iteration
        }

        // Attempt to move the uploaded file
        if (move_uploaded_file($_FILES["product_images"]["tmp_name"][$key], $target_file)) {
            echo "The file " . htmlspecialchars(basename($filename)) . " has been uploaded.";

            // Insert the image name into the database
            $imageName = $randomNumber . "_" . $filename;

            $query = "INSERT INTO product_images (product_id, product_image_name) VALUES ('$max_id', '$imageName')";
            $insert = db::query($query);

            if ($insert) {
                $status = 1;
                header("Location: products.php?status=" . $status);
            }

        }
    }
}


if (isset($_POST['update_product'])) {
    // Open database connection
    $db = db::open();
    // Sanitize and escape user input
    $product_title = $db->real_escape_string($_POST['update_product_title']);
    $product_description = $db->real_escape_string($_POST['update_product_description']);
    $product_description_short = $db->real_escape_string($_POST['update_product_description_short']);
    $product_id = $db->real_escape_string($_POST['id']);
    $product_price = $db->real_escape_string($_POST['update_product_price']);
    $product_stock = $db->real_escape_string($_POST['update_product_stock']);
    $product_feature = $db->real_escape_string($_POST['update_product_feature']);
    $product_update_category = $db->real_escape_string($_POST['update_category_id']);
    $product_update_sub_category = $db->real_escape_string($_POST['update_sub_category_id']);
   
    if (isset($product['update_product_stock'])) {
        $product['update_product_stock'] = 0;
    }
    if (isset($product['update_product_feature'])) {
        $product['update_product_feature'] = 0;
    }
    // Update product in the database
    $query = "UPDATE products SET product_title='$product_title' , product_description='$product_description',product_description_short='$product_description_short', product_price='$product_price',  product_stock='$product_stock',product_feature='$product_feature',category_id='$product_update_category',sub_category='$product_update_sub_category' WHERE id = '$product_id'";
    $update = db::query($query);

    $fileNames = $_FILES['image_update']['name'];
    $fileSizes = $_FILES['image_update']['size'];
    $fileErrors = $_FILES['image_update']['error'];
    
    $uploadErrors = [];
    
    $query = "SELECT * FROM product_images WHERE product_id = '$product_id'";
    $product_images = db::getRecords($query);
    $old_image_names = [];
    foreach ($product_images as $product_image) {
        $old_image_names[] = $product_image['product_image_name'];
    }
    
    // Delete the old image files from the uploads folder
    $target_dir = "uploads/products/";
    $productImagesArray = json_decode($_POST['updatedArrayInput'], true); // Get the updated array from the hidden input
    
    if (is_array($productImagesArray) && is_array($old_image_names)) {
        foreach ($old_image_names as $old_image_name) {
            if (!in_array($old_image_name, $productImagesArray)) {
                $old_image_path = $target_dir . $old_image_name;
                if (file_exists($old_image_path)) {
                    unlink($old_image_path); // Delete the file
                }
            }
        }
    
        // Delete the images from the database
        if (!empty($old_image_names)) {
            $delete_image_names = array_diff($old_image_names, $productImagesArray);
            foreach ($delete_image_names as $delete_image_name) {
                $query = "DELETE FROM product_images WHERE product_id = '$product_id' AND product_image_name = '$delete_image_name'";
                $delete = db::query($query);
            }
        }
    }
    if (!empty($fileNames[0])) {
        // Delete the images from the database
     
        foreach ($fileNames as $key => $name) {
            $fileSizeKB = $fileSizes[$key] / 29248;
            $maxFileSizeKB = 500 * 29248;

            // Check if file is an image
            $allowedExtensions = array("jpg", "jpeg", "png", "gif", "bmp", "tiff", "webp");
            $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            if (!in_array($extension, $allowedExtensions)) {
                $uploadErrors[] = "Sorry, only JPG, JPEG, PNG, GIF, BMP, and TIFF files are allowed for file '$name'.";
                continue; // Skip this file and proceed to the next iteration
            }

            if ($fileSizeKB > $maxFileSizeKB) {
                $uploadErrors[] = "Sorry, your file '$name' is too large. Maximum file size is $maxFileSizeKB KB.";
                continue; // Skip this file and proceed to the next iteration
            }

            // Set target directory and file path
            $target_dir = "uploads/products/";
            $randomNumber = mt_rand(100000, 999999);
            $target_file = $target_dir . $randomNumber . "_" . $name;

            // Check if file already exists
            while (file_exists($target_file)) {
                $randomNumber = mt_rand(100000, 999999);
                $target_file = $target_dir . $randomNumber . "_" . $name;
            }

            // Attempt to move the uploaded file
            if (move_uploaded_file($_FILES["image_update"]["tmp_name"][$key], $target_file)) {
                // Insert the image name into the database
                $imageName = $randomNumber . "_" . $name;
                $query = "INSERT INTO product_images (product_id, product_image_name) VALUES ('$product_id', '$imageName')";
                $insert = db::query($query);

                if ($insert) {
                    $status = 3;
                    header("Location: products.php?status=" . $status);

                } else {
                    $uploadErrors[] = "Failed to insert image '$name' into product_images table: " . $db->error;
                }
            } else {
                $uploadErrors[] = "Failed to upload image '$name'.";
            }
        }
    }

    // Handle the upload errors, if any
    if (!empty($uploadErrors)) {
        foreach ($uploadErrors as $error) {
            echo $error . "<br>";
        }
    }
    if ($update) {
        $status = 3;
        header("Location: products.php?status=" . $status);
    }
}




if (isset($_POST['delete_product'])) {
    $db = db::open();
    $product_id = $db->real_escape_string($_POST['product_id']);

    $query = "SELECT * FROM product_images WHERE product_id = '$product_id'";
    $product_images = db::getRecords($query);
    $old_image_names = [];

    foreach ($product_images as $product_image) {
        $old_image_names[] = $product_image['product_image_name'];
    }

    // Delete the old image files from the uploads folder
    foreach ($old_image_names as $old_image_name) {
        $target_dir = "uploads/products/";

        $old_image_path = $target_dir . $old_image_name;
        $old_image_files = glob($old_image_path); // Get all files matching the path

        foreach ($old_image_files as $file) {
            if (is_file($file)) {
                unlink($file); // Delete the file
            }
        }
    }
    // Delete the images from the database
    $query = "DELETE FROM product_images WHERE product_id = '$product_id'";
    $delete = db::query($query);
    $query = "DELETE FROM products WHERE id = '$product_id'";
    $delete = db::query($query);
    $status = 2;
    header("Location: products.php?status=" . $status);



}


if (isset($_POST['mark_as_paid'])) {
    $db = db::open();
    $order_id = $_POST['order_id'];
    $status = 1;
    $query = "UPDATE orders SET payment_status = '$status' WHERE order_id = '$order_id'";
    $update = db::query($query);
    $status = 1;
    header("Location: orders.php?status=" . $status);
}



if (isset($_POST['delete_order'])) {
    $db = db::open();
    $order_id = $_POST['order_id'];
    $query = "DELETE FROM orders WHERE order_id = '$order_id'";
    $update = db::query($query);
    $status = 2;
    header("Location: orders.php?status=" . $status);
}
?>