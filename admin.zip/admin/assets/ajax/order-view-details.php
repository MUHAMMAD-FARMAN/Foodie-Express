<?php

require_once('../../database.php');

$order_id = $_POST['order_id'];
$query = "SELECT * FROM orders WHERE order_id = '$order_id' ORDER BY id DESC";
$order = db::getRecord($query);

$full_name = $order['full_name'];
$email = $order['email'];
$phone = $order['phone'];
$address = $order['address'];
$city = $order['city'];
$postal_code = $order['postal_code'];
$notes = $order['notes'];
$total_products = $order['total_products'];
$total_bill = $order['total_bill'];
$order_status = $order['payment_status'];
$payment_method = $order['payment_method'];
$country = $order['country'];


?>

<div class="row">
    <h1 class="text-center">Order: <u>#
            <?php echo $order_id;    ?>
        </u> </h1>
</div>

<h2>Customer Details</h2>
<div class="row g-3 offset-1   my-4  ">
    <div class="col-lg-3">
        <div class="content d-flex align-items-center  ">
            <h5 class="mb-0">Full Name:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $full_name; ?>
            </p>
        </div>
    </div>
   
    <div class="col-lg-3">
        <div class="content d-flex align-items-center ">
            <h5 class="mb-0">Email:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $email; ?>
            </p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="content d-flex align-items-center ">
            <h5 class="mb-0">Phone:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $phone; ?>
            </p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="content d-flex align-items-center  ">
            <h5 class="mb-0">Address:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $address; ?>
            </p>
        </div>
    </div>
</div>


<div class="row g-3  offset-1  mt-4  ">
    <div class="col-lg-3">
        <div class="content d-flex align-items-center ">
            <h5 class="mb-0">Postal Code:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $postal_code; ?>
            </p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="content d-flex align-items-center ">
            <h5 class="mb-0">City:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $city; ?>
            </p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="content d-flex align-items-center ">
            <h5 class="mb-0">Country:</h5>
            <p class="mb-0 fs-6 ms-2 text-nowrap">
                <?php echo $country; ?>
            </p>
        </div>
    </div>
</div>
<h2 class="mt-5">Order Details</h2>


<div class="row my-5">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="row g-3    ">
                    <div class="col-lg-3 d-flex ">
                        <div class="content d-flex align-items-center  ">
                            <h5 class="mb-0">Order Status:</h5>
                            <p class="mb-0 fs-6 ms-2 text-nowrap <?php
                            if ($order_status == 0) {
                                echo "btn btn-info";
                            } else if ($order_status == 1) {
                                echo 'btn btn-info';
                            } else if ($order_status == 2) {
                                echo 'btn btn-success';
                            }
                            ?> ">
                                <?php
                                if ($order_status == 0) {
                                    echo "Active";
                                } else if ($order_status == 1) {
                                    echo 'Completed';
                                }

                                ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="content d-flex align-items-center ">
                           
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="content d-flex align-items-center ">
                            <h5 class="mb-0">Total Products:</h5>
                            <p class="mb-0 fs-6 ms-2 text-nowrap btn btn-white">
                                <?php echo $total_products; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="content d-flex align-items-center ">
                            <h5 class="mb-0">Total Bill:</h5>
                            <p class="mb-0 fs-6 ms-2 text-nowrap btn btn-white">$
                                <?php echo $total_bill; ?>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-body">
                <div class="table-responsive  border border-1">
                    <table class="table table-nowrap align-middle table-borderless mb-0">
                        <thead class="table-light text-muted">
                            <tr>
                                <th scope="col">Product Details</th>
                                <th scope="col">Item Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col" class="text-end">Total Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT *  from order_details WHERE order_id='$order_id'";
                            $order_details = db::getRecords($query);
                            if (!empty($order_details)) {
                                foreach ($order_details as $order_detail) {
                                    $product_id = $order_detail['product_id'];
                                    $product_quantity = $order_detail['quantity'];
                                    $product_price = $order_detail['price'];
                                    $product_total_price = $order_detail['total_price'];

                                    $query = "SELECT *  from products WHERE id='$product_id'";
                                    $product = db::getRecord($query);

                                    $query = "SELECT *  from product_images WHERE product_id='$product_id'";
                                    $product_images = db::getRecords($query);
                                    $product_image = $product_images[0]['product_image_name'];
                                    ?>

                                    <tr>
                                        <td>
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 avatar-md bg-light rounded p-1">
                                                    <img src="./uploads/products/<?php echo $product_image; ?>" alt=""
                                                        class="img-fluid d-block">
                                                </div>
                                                <div class="flex-grow-1 ms-3 d-flex  align-items-center">
                                                    <h5 class="fs-15">
                                                        <p class="link-primary">
                                                            <?php echo $product['product_title']; ?>
                                                        </p>
                                                    </h5>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            $<?php echo $product_price; ?>
                                        </td>
                                        <td>
                                            <?php echo $product_quantity ?>
                                        </td>

                                        <td class="fw-medium text-end">
                                           $ <?php echo $order_detail['total_price']; ?>
                                        </td>
                                    </tr>


                                    <?php
                                }
                            }
                            ?>

                                </tbody>

                            </table>





                </div>
               
            </div>
            <div class="card-footer">
                    <div class="row g-3">
                        <div class="col-lg-3">
                            <div class="content ">
                                <h5 class="mb-0">Order Note:</h5>
                                <p class="mb-0 fs-6 ms-2 text-nowrap btn btn-white">
                                    <?php echo $order['notes'] ?>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
        </div>

        <div class="justify-content-end d-flex ">
            <button name='add-banner' data-bs-dismiss='modal' aria-label='Close'
                class='btn btn-light fs-4 px-5 py-2   waves-effect waves-light '>Cancel</button>
        </div>
    </div>

</div>

</div>