<?php

require_once('../../database.php');




$db = db::open();
$id = $_POST['product_id'];
$query = "SELECT * from products WHERE  id = '$id'";
$product = db::getRecord($query);
$category_id = $product['category_id'];



$query = "SELECT *  from categories WHERE id = '$category_id'";
$category = db::getRecord($query);

$sub_category_id =   $product['sub_category'];


$query = "SELECT * from sub_categories WHERE id = '$sub_category_id'";
$sub_category = db::getRecord($query);




if ($product != NULL) { ?>
<div class='row mt-5 align-items-center'>

    <?php if ($product != Null) {
                $id = $product['id'];
                $product_description = $product['product_description'];
                $product_description_short = $product['product_description_short'];
                $query = "SELECT * from product_images where product_id='$id'";
                $product_images = db::getRecords($query);
                $carousel_main_id = 'abcdefgh';



                ?>
    <div class="col-lg-6 mb-3 ">
        <div class="card  ">
            <!-- Individual Slide -->

            <div id='<?php echo $carousel_main_id ?>' class="carousel carousel-dark slide carousel-fade"
                data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php if ($product != NULL) {

                                    if (!is_array($product_images)) {
                                        $product_images = array($product_images);
                                    }
                                    foreach ($product_images as $product_image) { ?>
                    <div class="carousel-item active" data-bs-interval="10000">
                        <img class='card-img-top'
                            src='uploads/products/<?php echo $product_image['product_image_name'] ?>' alt='done d'>
                    </div>
                    <?php }
                                } ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo $carousel_main_id ?>"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#<?php echo $carousel_main_id ?>"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
    <div class="col-lg-6 ps-lg-5">
        <div class="row">
            <div class="col-lg-6">
                <div class="heading mb-4">
                    <h2 class="text-dark">Name</h2>
                    <h5 class="text-grey mt-3">
                        <?php echo $product['product_title']; ?>
                    </h5>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="heading mb-4">
                    <h2 class="text-dark">Price</h2>
                    <h5 class="text-grey mt-3">
                        $<?php echo$product['product_price']; ?>
                    </h5>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="heading mb-4">
                    <h2 class="text-dark">Category </h2>
                    <h5 class="text-grey mt-3">
                        <?php echo$category['title']; ?>
                    </h5>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="heading mb-4">
                    <h2 class="text-dark">Sub Category </h2>
                    <h5 class="text-grey mt-3">
                        <?php echo$sub_category['title']; ?>
                    </h5>
                </div>
              </div>
          </div>
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="text-dark">Stock</h2>

                    <div class="heading mb-4">

                        <h5 class="<?php if ($product['product_stock'] == 1) {
                            echo "badge badge-soft-danger fs-5";
                        } else {
                            echo "badge badge-soft-primary fs-5";
                        } ?> ?>">

                            <?php if ($product['product_stock'] == 1) {
                                echo "Not Available In Stock";

                            } else {
                                echo "Available In Stock";

                            } ?>
                        </h5>
                    </div>


                </div>
                <div class="col-lg-6">
                    <h2 class="text-dark">Feature</h2>

                    <div class="heading mb-4">

                        <h5 class="<?php if ($product['product_feature'] == 1) {
                            echo "badge badge-soft-primary fs-5";
                        } else {
                            echo "badge badge-soft-danger fs-5";
                        } ?> ?>">

                            <?php if ($product['product_feature'] == 1) {
                                echo "Product is Featured";
                            } else {
                                echo "Product is not Featured";
                            } ?>
                        </h5>
                    </div>
                </div>


                <div class="col-lg-12">
                    <div class="heading mb-4">
                        <h2 class="text-dark">Short Description</h2>
                        <h5 class="text-grey mt-3">
                            <?php echo $product_description_short ?>
                        </h5>
                    </div>
                </div>


                    <div class="col-lg-12">
                        <div class="heading mb-4 text-responsive">
                            <h2 class="text-dark">Long Description</h2>
                            <?php echo $product_description ?>
                        </div>
                    </div>

                    <div class="heading my-3 d-flex justify-content-end">
                        <button type="button" data-bs-dismiss="modal"
                            class="btn btn-light waves-effect waves-light btn-lg btn-block">Close</button>
                    </div>
             </div>

                <?php 
        }
} ?>