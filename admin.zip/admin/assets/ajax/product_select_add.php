<?php

require_once('../../database.php');
$db = db::open();

$category_id = $_POST['category_id'];

$query = "SELECT * FROM sub_categories WHERE category_id='$category_id'";
$sub_categories = db::getRecords($query);

?>


<?php if ($sub_categories != NULL) {
?>
    <label for="sub_categories" class=" form-label fs-4" >Sub Category</label>
    <select id="sub_category" class="sub_category_select" name="add_sub_category_id">
        <option></option>

        <?php
        foreach ($sub_categories as $sub_category) {
        ?>

            <option value="<?php echo $sub_category['id'] ?>"><?php echo $sub_category['title'] ?></option>
        <?php
        }
        ?>
        <script>
            $(".sub_category_select").select2({
                placeholder: 'Select a Sub Category ',
                // dropdownParent: $('#modal-add .modal-content')
            });
        </script>

    </select>


<?php
} else {
?>

    <script>
        $(".sub_category_select").select2({
            placeholder: 'There are no sub_categories available for this category',
            // dropdownParen    t: $('#modal-add .modal-content')
        });
    </script>
<?php
}
?>


