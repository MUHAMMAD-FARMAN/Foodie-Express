<?php

require_once('../../database.php');
$db = db::open();
$product_id = $db->real_escape_string($_POST['product_id']);


$query = "SELECT * from products where id='$product_id'";

$product = db::getRecord($query);
$product_category_id = $product['category_id'];


$query = "SELECT * FROM categories";
$categories = db::getRecords($query);


$query = "SELECT * FROM sub_categories where category_id='$product_category_id'";
$sub_categories = db::getRecords($query);



$product_description = $product['product_description'];

if ($categories != NULL) {

?>



    <div class="mb-3">


        <div class="align-self-center categories_edit_div">
            <label for="categories_edit">Select a Category</label>
            <select id="categories_edit" class="categories_select_edit" name="update_category_id"
                onchange="show_sub_category_edit(this)">
                <?php
             
                foreach ($categories as $category) {
                  ?>
                    <option <?php if ($product['category_id'] == $category['id']) {
                        echo "Selected";
                    } ?> value="<?php echo $category['id'] ?>"><?php echo $category['title'] ?></option>
                    <?php
                }
                ?>
            </select>
            <script>
                $(".categories_select_edit").select2({
                    placeholder: 'Select a Category ',
                    // dropdownParent: $('#modal_edit .modal-content')
                });
            </script>
        </div>
    </div>
    <?php
} else {

    ?>
    <script>
        $(".sub_categories_select_edit").select2({
            placeholder: 'No Sub Category Available',
            dropdownParent: $('#modal_edit .modal-content')
        });
    </script>
    <?php
}
?>

<?php
if ($sub_categories != NULL) {
    // print_r($sub_categories);
    ?>
    <div class="mb-3">

            <label for="categories_edit">Select a Sub Category</label>
          <div id="edit_sub_category_ajax" >
            <select id="sub_categories_edit" class="sub_categories_select_edit" name="update_sub_category_id">
                <?php
                if ($product['sub_category'] == NULL) {
                 
                }
                foreach ($sub_categories as $sub_category) {
                    ?>
                    <option <?php if ($product['sub_category'] == $sub_category['id']) {
                        echo "Selected";
                    } ?> value="<?php echo $sub_category['id'] ?>"><?php echo $sub_category['title'] ?></option>
                    <?php
                }
                ?>
            </select>
            <script>
                $(".sub_categories_select_edit").select2({
                    placeholder: 'Select a Sub Category',
                    // dropdownParent: $('#modal_edit .modal-content')
                });
            </script>

        </div>
    </div>
    <?php
} else {


    ?>
   
    <script>
        $(".sub_categories_select_edit").select2({
            placeholder: 'No Sub Category Available',
            // dropdownParent: $('#modal_edit .modal-content')
        });
    </script>
<?php } ?>

<!-- 

<div class="mb-3">
    <label for="title" class="form-label">Edit Product Title</label>
    <input type="text" value="<?php echo $product['product_title'] ?>" class="form-control" id="edit_title"
        name="update_product_title">
</div>

<div class="mb-3">
    <div>
        <label for="description" class="form-label">Edit Product Price</label>
    </div>
    <div class="input-group mb-3">

        <span class="input-group-text ">$</span>
        <input value="<?php echo $product['product_price'] ?>" type="text" class="form-control"
            name="update_product_price" id="price" aria-label="Dollar amount (with dot and two decimal places)">
    </div>
</div>

<div class="mb-3">
    

    <div>
        <label for="description" class="form-label">Product Out Of Stock</label>
    </div>
   
    <div class="form-check form-switch form-switch-lg" dir="ltr">
    <input type="checkbox" name="update_product_stock" <?php if($product['product_stock'] == 1) { echo 'checked';} ?> class="form-check-input" class="customSwitchsizelg" >
</div>

<div>
        <label for="description" class="form-label">Feature the Product</label>
    </div>
    <div class="form-check form-switch form-switch-lg" dir="ltr">
    <input type="checkbox" name="update_product_feature" <?php if($product['product_feature'] == 1) { echo 'checked';} ?> class="form-check-input" class="customSwitchsizelg" >

</div>

</div>


<div class="mb-3">
    <label for="description" class="form-label">Edit Product Description</label>
    <textarea class="w-100 form-control"
        name="update_product_description_short"><?php echo $product_description_short ?></textarea>
</div>


<div class="mb-3">
    <label for="description" class="form-label">Edit Product Description</label>
    <textarea class="ckeditor" 
        name="update_product_description"><?php echo $product_description ?></textarea>
</div> -->
