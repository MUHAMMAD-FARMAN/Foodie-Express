
<?php

require_once('../../database.php');
$db = db::open();
$product_id = $db->real_escape_string($_POST['product_id']);



$query = "SELECT * from sub_categories where category_id='$product_id'";
$sub_categories = db::getRecords($query);




?>
<script>  $("#sub_category").select2({

placeholder: 'Please Select a Category'

});

</script>

<?php if ($sub_categories != NULL) {
?>
    <select id="sub_category" class="sub_category_select" name="update_sub_category_id">
        <option ></option>
        <?php
        foreach ($sub_categories as $sub_category) {
        ?>

            <option value="<?php echo $sub_category['id'] ?>"><?php echo $sub_category['title'] ?></option>
        <?php
        }
        ?>
       
    </select>


<?php } ?>
