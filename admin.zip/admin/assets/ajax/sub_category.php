<?php

require_once("../../database.php");
$db = db::open();
$category_id = $db->real_escape_string($_POST['category_id']);

$query = "SELECT *  from categories";
$categories = db::getRecords($query);

?>
<div class="mb-3">

    <label for='update_sub_category_image' class='form-label fs-4  '> Choose Category </label>
    <select class="select2-selection select2-selection--single form-control category_select_edit    "
        name="update_select_id">
        <?php if ($categories == NULL) { ?>
        <option></option>
        <?php } ?>
        <?php if ($categories != NULL) {
            foreach ($categories as $category) {
                ?>

        <option <?php
                if ($category['id'] == $category_id) {
                    echo "selected";
                }
                ?> value="<?php echo $category['id'] ?>">
            <?php echo $category['title'] ?></option>

        <?php
            }
        } else {
            ?>

        <script>
        $(document).ready(function() {
            $(".category_select_edit").select2({
                placeholder: 'No Category Available',
                dropdownParent: $('#edit-modal .modal-content')
            });
        })
        </script>
        <?php
        }
        ?>
        <script>
        $(document).ready(function() {
            $(".category_select_edit").select2({
                placeholder: 'Please Select a Category',
                dropdownParent: $('#edit-modal .modal-content')
            });
        })
        </script>