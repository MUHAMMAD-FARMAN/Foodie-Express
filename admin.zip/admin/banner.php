<?php include('header.php');


require_once('database.php');




$db = db::open();
$query = "SELECT *  from banners";
$banners = db::getRecords($query);

?>

<div class='main-content'>
    <div class='page-content'>
        <div class='container-fluid'>
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">

                        <h3 class="text-center text-white my-2">Banners</h3>
                    </div>
                </div>
            </div>
            <!--end row-->
            <div class="row">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="./banner.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Banners</li>
                        </ol>
                        <div class="page-title-right">
                            <button type='button' class='btn custom-gradient    text-white  fs-7 '
                                data-bs-toggle='modal' data-bs-target='#add-banner'>Add New banner</button>
                        </div>
                    </div>
                </div>
            </div>





            <div class='row mt-5'>
                <?php
                if ($banners != Null) {
                    foreach ($banners as $banner) {
                        $banner_image = "./uploads/banners/" . $banner['image_name'];
                        $banner_description = $banner['banner_description'];

                        ?>
                        <div class='col-md-6'>
                            <div class='card style="width:100%" '>
                                <img class='card-img-top' loading="lazy" height="300px" src='<?php echo $banner_image ?>'
                                    alt='banner-image   '>
                                <div class='card-body'>

                                    <h3 class="text-center  my-3">
                                        <?php echo $banner['banner_title']; ?>

                                    </h3>


                                </div>
                                <div class='card-footer pt-4 mt-3  d-flex justify-content-between text-center'>
                                    <button type='button' class='btn btn-primary waves-effect waves-light btn-xxl float-left'
                                        onclick="view_modal('<?php echo $banner['banner_title']; ?>','<?php echo $banner_description ?>','<?php echo $banner_image ?>')"><i
                                            class='fas fa-eye'></i></button>
                                    <button type='button' class='btn btn-success btn-xl  waves-effect waves-light'
                                        onclick="edit_modal('<?php echo $banner['id']; ?>','<?php echo $banner['banner_title']; ?>','<?php echo $banner_description ?>')"><i
                                            class='fas fa-user-edit'> </i></button>
                                    <button type='button' class='btn btn-danger waves-effect waves-light btn-xl float-right'
                                        onclick="delete_modal('<?php echo $banner['id']; ?>')"><i
                                            class='fas fa-trash'></i></button>
                                </div>
                            </div><!-- end card -->
                        </div>
                    <?php }
                } ?>

            </div>

        </div>
    </div>



    <div id='view-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true' style='display: none;'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content border-0 border-0'>
                <div class='close d-flex justify-content-between align-items-center  px-4 py-3 '>
                    <h2 class='text-black'>View Details</h2>
                    <button type='button' class='btn-close  mt-n2 opacity-100' data-bs-dismiss='modal'
                        aria-label='Close'></button>
                </div>
                <div class=' modal-body py-3 px-5'>
                    <div class='heading my-3'>
                        <h3>Bannner Image</h3>
                    </div>
                    <img class='card-img-top' id="banner_image" alt=''>
                    <div class='heading my-3'>
                        <h3 class='my-3'>Banner Title</h3>
                        <h2 id="banner_title" class='mt-2 fs-5'>

                        </h2>
                    </div>
                    <div class='heading my-3'>
                        <h3 class='my-3'>Bannner Description</h3>
                        <p class='mt-2' id="banner_description"></p>
                    </div>
                    <div class='heading my-3 float-start'>
                        <button type='button' data-bs-dismiss="modal"
                            class='btn btn-light waves-effect waves-light btn-lg '>Close</button>
                    </div>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </div>



    <div id='add-banner' class='modal fade' aria-labelledby='add-banner' aria-hidden='true' style='display: none;'>
        <div class='modal-dialog modal-dialog-centered'>
            <div class='modal-content border-0'>
                <div class='close d-flex justify-content-between align-items-center border-bottom border-black  px-4 py-3  '>
                    <h2 class='text-black m-0'>Add banner </h2>
                    <button type='button' class='btn-close  mt-n2 opacity-100' data-bs-dismiss='modal'
                        aria-label='Close'></button>
                </div>
                <div class=' modal-body py-lg-3 px-lg-5'>




                    <form action='action.php' enctype="multipart/form-data" method='post'>
                        <div class='heading my-3'>
                            <div class='mb-3'>
                                <label for='banner-title' class='form-label fs-4  '>Banner Image</label>
                                <input type='file' multiple class='form-control' name='banner-image' id='text'
                                    placeholder='Enter title' required>
                            </div>
                        </div>
                        <div class='heading my-3'>
                            <div class='mb-3'>
                                <label for='banner-banner_title' class='form-label fs-4  '>Banner Heading</label>
                                <input type='text' class='form-control' name='banner-title' id='text'
                                    placeholder='Enter title' required>
                            </div>
                        </div>
                        <div class='heading my-3'>
                            <div class='mb-3'>
                                <label for='banner_description' class='form-label fs-4  '>Enter Banner
                                    Description</label>
                                <textarea name="banner_description" class="form-control" id="banner_description"
                                    rows="4"></textarea>

                            </div>
                        </div>
                        <div class="btn d-flex justify-content-between">


                            <button name='add-banner' data-bs-dismiss='modal' aria-label='Close'
                                class='btn btn-light btn-lg   waves-effect waves-light '>Cancel</button>
                            <button type='submit' name='add-banner' class='btn btn-dark btn-lg '>Add banner</button>
                        </div>
                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->

    </div>


</div>

<div id='edit-modal' class='modal fade' aria-labelledby='edit-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                <h2 class='text-white'>Edit Details</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <form action="action.php" method="post" enctype="multipart/form-data">
                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <label for='image_banner' class='form-label fs-4  '>Banner Image</label>
                            <input type="file" multiple class="form-control" name="image_banner" />
                        </div>
                    </div>
                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <label for='banner-banner_title' class='form-label fs-4 my-2'>Banner Heading </label>
                            <input id="banner_update_id" type="hidden" name="id_banner">
                            <input type='text' class='form-control' name='title_banner' id='update_banner_title'>
                        </div>
                    </div>
                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <label for='banner_description' class='form-label fs-4  '>Enter Banner Description</label>
                            <textarea name="banner_description" class="form-control" id="update_banner_description"
                                rows="4"></textarea>

                        </div>
                    </div>
                    <div class='heading my-3'>
                        <div class='mb-3 d-flex justify-content-between'>

                            <button type="button" data-bs-dismiss='modal' aria-label='Close'
                                class='btn btn-light    waves-effect waves-light btn-lg '>Cancel</button>
                            <button type='submit' name="update-banner"
                                class='btn btn-success    waves-effect waves-light btn-lg '>Update
                                banner</button>

                        </div>
                    </div>

                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
</div>


<div id='delete-modal' class='modal fade' aria-labelledby='delete-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered '>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-danger '>
                <h2 class='text-white'>Delete </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>

            <div class='modal-body '>
                <div class='mt-3 text-center mx-lg-3'>
                    <lord-icon src='https://cdn.lordicon.com/gsqxdxog.json' trigger='loop'
                        colors='primary:#f7b84b,secondary:#f06548' style='width:100px;height:100px'></lord-icon>
                    <div class='mt-4'>
                        <h4>Are you Sure ?</h4>
                        <p class='text-muted mt-3 mb-0'>Are you Sure You want to Delete this banner ?</p>
                        <form action="action.php" method="post">
                            <div class='d-flex justify-content-between  mt-4 mx-md-5'>

                                <input id="banner_id" type="hidden" name="banner-id">

                                <button type='button' data-bs-dismiss='modal' aria-label='Close'
                                    class='btn btn-light  btn-lg  waves-effect waves-light'>Cancel</button>
                                <button type='submit' name="delete-banner"
                                    class='btn btn-danger  btn-lg  waves-effect waves-light'>Yes Delete
                                    It</button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>
</div>
</div>



















<!-- JAVASCRIPT -->
<script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
<script src='assets/libs/simplebar/simplebar.min.js'></script>
<script src='assets/libs/node-waves/waves.min.js'></script>
<script src='assets/libs/feather-icons/feather.min.js'></script>
<script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
<script src='assets/js/plugins.js'></script>
<!-- Sweet Alerts js -->
<script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

<!-- Sweet alert init js-->
<script src='assets/js/pages/sweetalerts.init.js'></script>
<!-- calendar min js -->
<script src='assets/libs/fullcalendar/main.min.js'></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!-- Calendar init -->
<script src='assets/js/pages/calendar.init.js'></script>

<!-- App js -->
<script src='assets/js/app.js'></script>
<script>
    function view_modal(banner_title, banner_description, banner_image) {
        document.getElementById('banner_title').innerHTML = banner_title;
        document.getElementById('banner_description').innerHTML = banner_description;
        document.getElementById('banner_image').src = banner_image;
        $("#view-modal").modal('show');
    }

    function edit_modal(id, banner_title, banner_description) {
        document.getElementById('banner_update_id').value = id;
        document.getElementById('update_banner_title').value = banner_title;
        document.getElementById('update_banner_description').innerHTML = banner_description;
        $("#edit-modal").modal('show');
    }

    function delete_modal(id) {
        document.getElementById('banner_id').value = id;
        $("#delete-modal").modal('show');
    }
</script>
<script>
    const urlParams = new URLSearchParams(window.location.search);


    if (urlParams.get('status') === '1') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4>Banner Added</h4><p class="text-muted mx-4 mb-0">Banner Have Been Successfully Added</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }

    if (urlParams.get('status') === '2') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Banner Deleted</h4><p class="text-muted mx-4 mb-0">Banner Have Been Successfully Deleted</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }
    if (urlParams.get('status') === '3') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Banner Updated</h4><p class="text-muted mx-4 mb-0">Banner Have Been Successfully Updated</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }
</script>

</body>

</html>