<?php include('header.php');


if (isset($_GET['status'])) {
    $status = $_GET['status'];
}

$db = db::open();
$query = "SELECT *  from banners";
$banners = db::getRecords($query);
$total_banners = 0;
if(!empty($banners)) {
    $total_banners = count($banners);
} 




$query = "SELECT * from products";
$products = db::getRecords($query);
$total_products = 0;

if(!empty($products)) {
    $total_products = count($products);
}


$query = "SELECT *  from orders";
$orders = db::getRecords($query);
$total_orders = 0;

if(!empty($orders)) {
    $total_orders = count($orders);
}


$query = "SELECT *  from categories";
$categories = db::getRecords($query);
$total_categories = 0;

if(!empty($categories)) {
    $total_categories = count($categories);
}


$query = "SELECT *  from sub_categories";
$sub_categories = db::getRecords($query);
$total_sub_categories = 0;

if(!empty($sub_categories   )) {
    $total_sub_categories = count($sub_categories);
}


?>
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">
                        <div class="d-flex justify-content-center align-items-center mb-3 ">
                            <span
                                class="avatar-md rounded-circle p- rounded-circle  d-flex rounded fs-3 justify-content-center align-items-center "
                                style="background-color: #4839EB!important;">
                                <i class=" mdi mdi-trophy-award  fs-1 text-white "></i>
                        </div>
                        <h1 class="text-center text-white my-2">Welcome Admin</h1>
                    </div>
                </div>
            </div>

            <div class='row'>
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body   bg-seagreen rounded-2 ">

                            <h3 class="text-center text-white">Statistics</h3>
                        </div>
                    </div>
                </div>


                <!-- end page title -->
                <div class="row mt-4 ">
                    <!-- <div class="col-md-4 d-flex justify-content-center     ">
                        <div class="card  shadow-lg card-animate w-100 "
                            style="background: rgba(115 ,103, 240,.7)!important; ">
                            <div class="card-body  text-center p-4">
                                <div class="d-flex justify-content-center align-items-center ">
                                    <span style="background: rgb(106 92 251 / 76%)!important;;"
                                        class="avatar-md   rounded-circle p  d-flex rounded fs-3 justify-content-center align-items-center ">
                                        <i class="bx bx-images fs-1  text-white"></i> </span>
                                </div>
                                <h5 class="mb-1 mt-4 fs-3 text-dark"><a href="#" class="link-light">Banners</a>
                                </h5>
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div id="chart-seller1" data-colors='["--vz-danger"]'></div>
                                    </div>
                                </div>
                                <div class="row mt-4 justify-content-center">

                                    <div class="col-lg-6">
                                        <h5 class="text-white"><?php echo $total_banners; ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div> -->
                    <!--end col-->
                    <div class="col-md-4  d-flex justify-content-center     ">
                        <div class="card shadow-lg card-animate w-100"
                            style="background: rgb(74 186 124 / 79%)!important;">
                            <div class="card-body text-center p-4">
                                <div class="d-flex justify-content-center align-items-center ">
                                    <span
                                        class="avatar-md rounded-circle p bg-success d-flex rounded fs-3 justify-content-center align-items-center ">
                                        <i class="ri-shopping-basket-line fs-1  text-white"></i> </span>
                                </div>
                                <h5 class="mb-1 mt-4 fs-3 text-dark"><a href="#" class="link-light">Products</a>
                                </h5>
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div id="chart-seller1" data-colors='["--vz-danger"]'></div>
                                    </div>
                                </div>
                                <div class="row mt-4 justify-content-center">

                                    <div class="col-lg-6">
                                        <h5 class="text-white"><?php echo $total_products; ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--end col-->
                    <div class="col-md-4  d-flex justify-content-center    ">
                        <div class="card card-animate shadow-lg  w-100"
                            style="background: rgb(74 105 186 / 79%)!important;">
                            <div class="card-body text-center p-4">
                                <div class="d-flex justify-content-center align-items-center ">
                                    <span
                                        class="avatar-md rounded-circle d-flex rounded fs-3 justify-content-center align-items-center " style="background: rgb(74 105 186 / 79%)!important;" >
                                        <i class="bx bx-coin-stack  fs-1 text-white" ></i> </span> 
                                </div>
                                <h5 class="mb-1 mt-4 fs-3 text-dark"><a href="#" class="link-light"> Orders</a>
                                </h5>
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div id="chart-seller1" data-colors='["--vz-danger"]'></div>
                                    </div>
                                </div>
                                <div class="row mt-4 justify-content-center">

                                    <div class="col-lg-6">
                                        <h5 class="text-white"><?php echo $total_orders; ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4  d-flex justify-content-center    ">
                        <div class="card card-animate shadow-lg  w-100"
                            style="background: rgb(234 188 84 / 55%)!important;">
                            <div class="card-body text-center p-4">
                                <div class="d-flex justify-content-center align-items-center ">
                                    <span
                                        class="avatar-md rounded-circle p- bg-danger d-flex rounded fs-3 justify-content-center align-items-center " style="background: rgb(234 188 84 / 55%)!important;">
                                        <i class="bx bx-layer  fs-1 text-white"></i> </span>
                                </div>
                                <h5 class="mb-1 mt-4 fs-3 text-dark"><a href="#" class="link-light"> Categories</a>
                                </h5>
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div id="chart-seller1" data-colors='["--vz-danger"]'></div>
                                    </div>
                                </div>
                                <div class="row mt-4 justify-content-center">

                                    <div class="col-lg-6">
                                        <h5 class="text-white"><?php echo $total_categories; ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4  d-flex justify-content-center    ">
                        <div class="card card-animate shadow-lg  w-100"
                            style="background: rgb(234 84 85 / 55%)!important;">
                            <div class="card-body text-center p-4">
                                <div class="d-flex justify-content-center align-items-center ">
                                    <span
                                        class="avatar-md rounded-circle p- bg-danger d-flex rounded fs-3 justify-content-center align-items-center ">
                                        <i class="bx bx-window  fs-1 text-white"></i> </span>
                                </div>
                                <h5 class="mb-1 mt-4 fs-3 text-dark"><a href="#" class="link-light">Sub Categories</a>
                                </h5>
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div id="chart-seller1" data-colors='["--vz-danger"]'></div>
                                    </div>
                                </div>
                                <div class="row mt-4 justify-content-center">

                                    <div class="col-lg-6">
                                        <h5 class="text-white"><?php echo $total_sub_categories; ?></h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

        </div>
        <!-- end main content-->

        <?php include('footer.php')

            ?>


        <script>

            const urlParams = new URLSearchParams(window.location.search);

            if (urlParams.get('status') === '4') {
                // Show the Swal alert
                Swal.fire({
                    html: '<div class="mt-3"><img src="https://static.wixstatic.com/media/ce46d9_3f38fd870f0e44df928485e2e1c7686b~mv2.gif" trigger="loop" style="width:170px;height:120px"></im><div class="mt-4 pt-2 fs-15"><h4>Logged In</h4><p class="text-muted mx-4 mb-0">You Have been Successfully Logged In</p></div></div>',
                    showCancelButton: !0,
                    showConfirmButton: !1,
                    cancelButtonClass: "btn text-white  w-xs mb-1 bg",
                    cancelButtonText: "Dismiss",
                    buttonsStyling: !1,
                    showCloseButton: !0,
                }).then((result) => {
                    if (result.isConfirmed) {
                        // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                        history.pushState({}, '', window.location.pathname);
                    } else {
                        history.pushState({}, '', window.location.pathname);
                    }
                });
            }
            if (urlParams.get('status') === '3') {
                // Show the Swal alert
                Swal.fire({
                    html: "<div class='mt-3'><lord-icon src='https://cdn.lordicon.com/nxaaasqe.json' trigger='loop' colors='primary:#121331,secondary:#08a88a' style='width:100px;height:100px'></lord-icon><div class='mt-4 pt-2 fs-15'><h4>Password Updated</h4><p class='text-muted mx-4 mb-0'>Your Password Have been Successfully Changed</p></div></div>",
                    showCancelButton: !0,
                    showConfirmButton: !1,
                    cancelButtonClass: "btn text-white  w-xs mb-1 bg-success",
                    cancelButtonText: "Dismiss",
                    buttonsStyling: !1,
                    showCloseButton: !0,
                }).then((result) => {
                    if (result.isConfirmed) {
                        // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                        history.pushState({}, '', window.location.pathname);
                    } else {
                        history.pushState({}, '', window.location.pathname);
                    }
                });
            }


        </script>
        </body>

        </html>