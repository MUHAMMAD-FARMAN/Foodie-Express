<?php include('header.php');


$db = db::open();



$product_id = $_GET['id'];


$query = "SELECT * from products where id='$product_id'";
$product = db::getRecord($query);
$product_description = $product['product_description'];
$product_description_short = $product['product_description_short'];

$query = "SELECT * from product_images where product_id='$product_id'";
$product_images = db::getRecords($query);


$product_category_id = $product['category_id'];

$query = "SELECT * FROM categories";
$categories = db::getRecords($query);


$query = "SELECT * FROM sub_categories where category_id='$product_category_id'";
$sub_categories = db::getRecords($query);
$product_description = $product['product_description'];



?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">
                        <h3 class="text-center text-white my-2">Edit Product</h3>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="./dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Edit Product</li>
                        </ol>
                    </div>
                </div>
            </div>


            <div class="container mt-5">



                <div class="card">
                    <div class="card-body">


                        <form action="action.php" method="post" enctype="multipart/form-data">
                            <div class='row mt-5 justify-content-center'>
                                <div class="col-12">
                                    <div class="row justify-content-center">
                                        <div class="col--6">
                                            <div class="mb-3">
                                                <label for="formSizeDefault" class="form-label fs-5 fw-bold text-dark">
                                                    Product
                                                    Images</label>

                                                <div class="panel-body">
                                                    <form action="">
                                                        <div class="form-group">
                                                            <input type="file" name="image_update[]" id="images"
                                                                multiple class="form-control">
                                                        </div>
                                                        <div class="form-group">
                                                            <div style="width:100%;">

                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <input type="hidden" id="updatedArrayInput" name="updatedArrayInput"
                                                value="<?php echo json_encode($productImagesArray); ?>">

                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="row  justify-content-center" id="image_preview">

                                        <?php
                                            $productImagesArray = array();
                                            if (!empty($product_images)) {
                                            foreach ($product_images as $product_image) {
                                            array_push($productImagesArray, $product_image['product_image_name']); // Add image name to the productImagesArray
                                                ?>
                                        <div class="col-md-2">
                                            <div class="product_image shadow-lg mb-5  my-4">
                                                <img src="./uploads/products/<?php echo $product_image['product_image_name'] ?>"
                                                    alt="">
                                                <button type="button" onclick="removeImage(this)"
                                                    data-image="<?php echo $product_image['product_image_name']; ?>"
                                                    class="item-4"></button>
                                            </div>
                                        </div>
                                        <?php
    }
}
?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">

                                        <?php
                                        if ($categories != NULL) {
                                        
                                            ?>
                                        <div class="mb-3">


                                            <div class="align-self-center categories_edit_div">
                                                <label for="categories_edit"
                                                    class="form-label fs-5 fw-bold text-dark">Select a Category</label>
                                                <select id="categories_edit" class="categories_select_edit"
                                                    name="update_category_id" onchange="show_sub_category_edit(this)">
                                                    <?php
                                                     
                                                        foreach ($categories as $category) {
                                                          ?>
                                                    <option <?php if ($product['category_id'] == $category['id']) {
                                                                echo "Selected";
                                                            } ?> value="<?php echo $category['id'] ?>">
                                                        <?php echo $category['title'] ?></option>
                                                    <?php
                                                        }
                                                        ?>
                                                </select>

                                            </div>
                                        </div>
                                        <?php
                                        } ?>

                                        <div class="mb-3">
                                            <label for="" class="form-label fs-5 fw-bold text-dark">Select a Sub
                                                Category</label>
                                            <div id="update_sub_category_div">
                                                <select id="sub_category" class="sub_category_select"
                                                    name="update_sub_category_id">
                                                    <?php
        foreach ($sub_categories as $sub_category) {
        ?>

                                                    <option value="<?php echo $sub_category['id'] ?>">
                                                        <?php echo $sub_category['title'] ?></option>
                                                    <?php
        }
        ?>

                                                </select>
                                            </div>

                                        </div>



                                        <div class="mb-3">
                                            <label for="title" class="form-label fs-5 fw-bold text-dark"> Product
                                                Name</label>
                                            <input type="text" value="<?php
                                            echo $product['product_title'] ?>" class="form-control" id="edit_title"
                                                name="update_product_title">
                                        </div>
                                        <div class="mb-3">
                                            <div>
                                                <label for="description" class="form-label fs-5 fw-bold text-dark">
                                                    Product
                                                    Price</label>
                                            </div>
                                            <div class="input-group mb-3">

                                                <span class="input-group-text ">$</span>
                                                <input value="<?php echo $product['product_price'] ?>" type="text"
                                                    class="form-control" name="update_product_price" id="price"
                                                    aria-label="Dollar amount (with dot and two decimal places)">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <!-- <div class="col-lg-6">
                                                <div class="mb-3">


                                                    <div>
                                                        <label for="description"
                                                            class="form-label fs-5 fw-bold text-dark">Out
                                                            Of Stock</label>
                                                    </div>

                                                    <div class="form-check form-switch form-switch-lg" dir="ltr">
                                                        <input type="checkbox" value="1" name="update_product_stock" <?php if ($product['product_stock'] == 1) {
                                                                echo 'checked';
                                                            } ?> class="form-check-input">
                                                    </div>
                                                </div>
                                            </div> -->
                                            <div class="col-lg-12">
                                                <div class="mb-3">

                                                    <div>
                                                        <label for="description"
                                                            class="form-label fs-5 fw-bold text-dark">Feature the
                                                            Product</label>
                                                    </div>
                                                    <div class="form-check form-switch form-switch-lg" dir="ltr">
                                                        <input type="checkbox" value="1" name="update_product_feature" <?php if ($product['product_feature'] == 1) {
                                                                echo 'checked';
                                                            } ?> class="form-check-input">

                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="description" class="form-label fs-5 fw-bold text-dark">Product
                                                Short
                                                Description</label>
                                            <textarea class="w-100 form-control" rows="8"
                                                name="update_product_description_short"><?php echo $product_description_short ?></textarea>
                                        </div>



                                    </div>
                                    <div class="col-md-6">


                                        <div class="mb-3">
                                            <label for="description" class="form-label fs-5 fw-bold text-dark">Product
                                                Long
                                                Description</label>
                                            <textarea id="editor" style="height:000px;"
                                                name="update_product_description"><?php echo $product_description ?></textarea>
                                        </div>


                                    </div>
                                </div>


                                <div class="d-flex justify-content-between  ">
                                    <input type="hidden" name="id" value="<?php echo $product_id; ?>">
                                    <a href="./products.php" class="btn btn-lg btn-light">Cancel</a>
                                    <button type="submit" class="btn  btn-lg btn-success"
                                        name="update_product">Update</button>
                                </div>

                        </form>




                    </div>


                </div>
            </div>

        </div>
    </div>

















    <!-- JAVASCRIPT -->
    <script src="./assets/ckeditor/ckeditor.js"></script>

    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- swiper.init js -->
    <script src="assets/js/pages/swip er.init.js"></script>
    <script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
    <script src='assets/libs/simplebar/simplebar.min.js'></script>
    <script src='assets/libs/node-waves/waves.min.js'></script>
    <script src='assets/libs/feather-icons/feather.min.js'></script>
    <script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
    <script src='assets/js/plugins.js'></script>
    <!-- Sweet Alerts js -->
    <script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

    <!-- Sweet alert init js-->
    <script src='assets/js/pages/sweetalerts.init.js'></script>
    <!-- calendar min js -->
    <script src='assets/libs/fullcalendar/main.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <!-- Calendar init -->
    <script src='assets/js/pages/calendar.init.js'></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>

    <!-- App js -->
    <script src='assets/js/app.js'></script>

    <script>
    $(document).ready(function() {
        $(".categories_select_edit").select2({
            placeholder: 'Select a Category ',
            // dropdownParent: $('#modal_edit .modal-content')
        });

        $(".sub_categories_select_edit").select2({
            placeholder: 'No Sub Category Available',
        });
    });
    </script>
<script>
    // This sample still does not showcase all CKEditor 5 features (!)
    // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
    CKEDITOR.ClassicEditor.create(document.getElementById("editor"), {
        // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
        toolbar: {
            items: [

                'link', 'findAndReplace', 'selectAll', '|',
                'heading', '|',
                'bold', 'italic', 'strikethrough', 'underline', 'code', 'subscript', 'superscript',
                'removeFormat', '|',
                'bulletedList', 'numberedList', 'todoList', '|',
                'outdent', 'indent', '|',
                'undo', 'redo',
                '-',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
                'alignment', '|',
                'link', 'blockQuote', 'insertTable',
                '|',
                'specialCharacters', 'horizontalLine', 'pageBreak', '|'
                , '|',
            ],
            shouldNotGroupWhenFull: true
        },
        // Changing the language of the interface requires loading the language file using the <script> tag.
        // language: 'es',
        list: {
            properties: {
                styles: true,
                startIndex: true,
                reversed: true
            }
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
        heading: {
            options: [{
                    model: 'paragraph',
                    title: 'Paragraph',
                    class: 'ck-heading_paragraph'
                },
                {
                    model: 'heading1',
                    view: 'h1',
                    title: 'Heading 1',
                    class: 'ck-heading_heading1'
                },
                {
                    model: 'heading2',
                    view: 'h2',
                    title: 'Heading 2',
                    class: 'ck-heading_heading2'
                },
                {
                    model: 'heading3',
                    view: 'h3',
                    title: 'Heading 3',
                    class: 'ck-heading_heading3'
                },
                {
                    model: 'heading4',
                    view: 'h4',
                    title: 'Heading 4',
                    class: 'ck-heading_heading4'
                },
                {
                    model: 'heading5',
                    view: 'h5',
                    title: 'Heading 5',
                    class: 'ck-heading_heading5'
                },
                {
                    model: 'heading6',
                    view: 'h6',
                    title: 'Heading 6',
                    class: 'ck-heading_heading6'
                }
            ]
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
        placeholder: 'Write Description',
        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
        fontFamily: {
            options: [
                'default',
                'Arial, Helvetica, sans-serif',
                'Courier New, Courier, monospace',
                'Georgia, serif',
                'Lucida Sans Unicode, Lucida Grande, sans-serif',
                'Tahoma, Geneva, sans-serif',
                'Times New Roman, Times, serif',
                'Trebuchet MS, Helvetica, sans-serif',
                'Verdana, Geneva, sans-serif'
            ],
            supportAllValues: true
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
        fontSize: {
            options: [10, 12, 14, 'default', 18, 20, 22],
            supportAllValues: true
        },
        // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
        // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
        htmlSupport: {
            allow: [{
                name: /.*/,
                attributes: true,
                classes: true,
                styles: true
            }]
        },
        // Be careful with enabling previews
        // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
       
        // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
        link: {
            addTargetToExternalLinks: true,
            decorators: {
                defaultProtocol: 'https://',
                toggleDownloadable: {
                    mode: 'manual',
                    label: 'Downloadable',
                    attributes: {
                        download: 'file'
                    }
                },
                openInNewTab: {
                    mode: 'manual',
                    label: 'Open in a new tab',
                    defaultValue: true, // This option will be selected by default.
                    attributes: {
                        target: '_blank',
                        rel: 'noopener noreferrer'
                    }
                }
            }
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
       
        // The "super-build" contains more premium features that require additional configuration, disable them below.
        // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
        removePlugins: [
            // These two are commercial, but you can try them out without registering to a trial.
            // 'ExportPdf',
            // 'ExportWord',
            'CKBox',
            'CKFinder',
            'EasyImage',
            // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
            // Storing images as Base64 is usually a very bad idea.
            // Replace it on production website with other solutions:
            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
            // 'Base64UploadAdapter',
            'RealTimeCollaborativeComments',
            'RealTimeCollaborativeTrackChanges',
            'RealTimeCollaborativeRevisionHistory',
            'PresenceList',
            'Comments',
            'TrackChanges',
            'TrackChangesData',
            'RevisionHistory',
            'Pagination',
            'WProofreader',
            // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
            // from a local file system (file://) - load this site via HTTP server if you enable MathType.
            'MathType',
            // The following features are part of the Productivity Pack and require additional license.
            'SlashCommand',
            'Template',
            'DocumentOutline',
            'FormatPainter',
            'TableOfContents'
        ]
    });
    </script>

    <script>
    $(document).ready(function() {
        var fileArr = [];

        $("#images").change(function() {
            var total_file = document.getElementById("images").files;
            if (!total_file.length) return;

            for (var i = 0; i < total_file.length; i++) {
                if (total_file[i].size > 1048576) {
                    return false;
                } else {
                    fileArr.push(total_file[i]);
                    $('#image_preview').append(
                        "<div class='col-md-2'><div class='product_image mb-5 my-4' id='img-div" +
                        i +
                        "'><img src='" + URL.createObjectURL(event.target.files[i]) +
                        "' class='' title='" + total_file[i]
                        .name +
                        "'><div class='middle'><button  class='item-4' id='action-icon' value='img-div" +
                        i + "'  role='" + total_file[i].name +
                        "'></button></div></div></div>");
                }
            }
        });

        $('body').on('click', '#action-icon', function(evt) {
            var divName = this.value;
            var fileName = $(this).attr('role');
            $(this).closest('.col-md-2').remove();

            for (var i = 0; i < fileArr.length; i++) {
                if (fileArr[i].name === fileName) {
                    fileArr.splice(i, 1);
                }
            }
            document.getElementById('images').files = FileListItem(fileArr);
            evt.preventDefault();
        });

        function FileListItem(file) {
            file = [].slice.call(Array.isArray(file) ? file : arguments)
            for (var c, b = c = file.length, d = !0; b-- && d;) d = file[b] instanceof File
            if (!d) throw new TypeError("expected argument to FileList is File or array of File objects")
            for (b = (new ClipboardEvent("")).clipboardData || new DataTransfer; c--;) b.items.add(file[c])
            return b.files
        }
    });






    // Call the ImgUpload function when the document is ready.
    // $(document).ready(function () {
    //   ImgUpload($('.upload__img-wrap')); // Pass the correct imgWrap element to the function.
    // });
    // function ImgUpload(imgWrap) {
    //   var imgArray = [];

    //   $('.upload__inputfile').on('change', function (e) {
    //     var maxLength = $(this).attr('data-max_length');
    //     var files = e.target.files;
    //     var filesArr = Array.prototype.slice.call(files);

    //     filesArr.forEach(function (f, index) {
    //       if (!f.type.match('image.*')) {
    //         return;
    //       }

    //       if (imgArray.length >= maxLength) {
    //         return false;
    //       } else {
    //         var id = Date.now(); // Generate a unique ID for each image element.
    //         imgArray.push({ id: id, name: f.name}); // Store the image object with its ID and name in the imgArray.

    //         var reader = new FileReader();
    //         reader.onload = function (e) {
    //           var html = "<div class='col-md-2'><div style='background-image: url(" + e.target.result + ")' data-id='" + id + "' data-file='" + f.name + "' class='img-bg'><div class='upload__img-close'></div></div></div>";
    //           imgWrap.append(html);

    //           // Move the alert inside this block to see the updated array.
    //           alert(JSON.stringify(imgArray));
    //         };
    //         reader.readAsDataURL(f);
    //       }
    //     });
    //   });

    //   $('body').on('click', ".upload__img-close", function (e) {
    //     var file = $(this).parent().data("file");
    //     for (var i = 0; i < imgArray.length; i++) {
    //       if (imgArray[i].name == file) {
    //         imgArray.splice(i, 1);
    //         break;
    //       }
    //     }
    //     $(this).parent().parent().remove();
    //   });
    // }



    var productImagesArray = <?php echo json_encode($productImagesArray); ?>;

    function removeImage(button) {
        var imageDiv = button.parentNode.parentNode;
        if (imageDiv) {
            var imageName = button.getAttribute('data-image');

            // Check each element in the productImagesArray
            for (var i = productImagesArray.length - 1; i >= 0; i--) {
                if (productImagesArray[i] === imageName) {
                    productImagesArray.splice(i, 1); // Remove the matched element
                    break; // Exit the loop after the first match
                }
            }

            imageDiv.parentNode.removeChild(imageDiv);

            var hiddenInput = document.getElementById('updatedArrayInput');
            hiddenInput.value = JSON.stringify(productImagesArray);
        }

    }
    </script>
    <script>
    function change_sub_category(e) {
        const category_id = e.value;

        $.ajax({
            url: "assets/ajax/product_select_add.php",
            type: "POST",

            data: {
                category_id: category_id,
            },

            success: function(response) {

                $("#sub_category_ajax").html(response);


            },

        });



    }



    $("#add_select_category").select2({

        placeholder: 'Please Select a Category'
    });


    function edit_sub_category(e) {
        const category_id = e.value;

        $.ajax({
            url: "assets/ajax/product_select_edit.php",
            type: "POST",

            data: {
                category_id: category_id,
            },

            success: function(response) {

                $("#edit_sub_category_ajax").html(response);


            },

        });



    }


    $("#edit_select_category").select2({

        placeholder: 'Please Select a Category'
    });


    $("#sub_category").select2({

        placeholder: 'Please Select a Category'
    });





    function add_modal(category_id) {

        var category_id = category_id;

        $.ajax({
            url: "assets/ajax/product_carousel_load.php",
            type: "POST",

            data: {
                product_id: product_id,
            },

            success: function(response) {

                $("#add_modal").html(response);


            },

        });


        $("#view-modal").modal('show');
    }



    function view_modal(product_id) {

        var product_id = product_id;

        $.ajax({
            url: "assets/ajax/product_carousel_load.php",
            type: "POST",

            data: {
                product_id: product_id,
            },

            success: function(response) {

                $("#view_modal_data").html(response);


            },

        });

        $("#view-modal").modal('show');
    }


    function edit_modal(id) {

        document.getElementById("product_id").value = id;

        $.ajax({
            url: "assets/ajax/product_select_edit.php",
            type: "POST",

            data: {
                product_id: id,
            },

            success: function(response) {

                $(".edit_content_div").html(response);


            },

        });



        $("#add_select_category").select2({

            placeholder: 'Please Select a Category'
        });


        $("#edit-modal").modal('show');

    }

    function show_sub_category_edit() {
        var product_id = document.getElementById('categories_edit').value;
        $.ajax({
            url: "assets/ajax/show_sub_category_edit.php",
            type: "POST",
            data: {
                product_id: product_id,
            },
            success: function(response) {
                $("#update_sub_category_div").html(response);
            },
        });
    }


    function delete_modal(id) {

        document.getElementById('delete_product_id').value = id;
        $("#delete-modal").modal('show');
    }
    </script>



    <script>
    const urlParams = new URLSearchParams(window.location.search);


    if (urlParams.get('status') === '1') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4>Product Added</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Added</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }

    if (urlParams.get('status') === '2') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Product Deleted</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Deleted</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }
    if (urlParams.get('status') === '3') {
        // Show the Swal alert
        Swal.fire({
            html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Product Updated</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Updated</p></div></div>',
            showCancelButton: !0,
            showConfirmButton: !1,
            cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
            cancelButtonText: "Close",
            buttonsStyling: !1,
            showCloseButton: !0,
        }).then((result) => {
            if (result.isConfirmed) {
                // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
                history.pushState({}, '', window.location.pathname);
            } else {
                history.pushState({}, '', window.location.pathname);
            }
        });
    }
    </script>
    </body>

    </html>