






 <!--start back-to-top-->
 <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <footer class="footer ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <p>&copy; Copyright
                        <script>
                        document.write(new Date().getFullYear());
                        </script> Single Solution.
                    </p>
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        <p> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- end main content-->




<!-- JAVASCRIPT -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script src="assets/ckeditor/ckeditor.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/feather-icons/feather.min.js"></script>
<script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>

<!-- Select 2 -->

<script src="assets/js/pages/select2.init.js"></script>
<!-- profile-setting init js -->
<script src="assets/js/pages/profile-setting.init.js"></script>
<!-- swiper js -->
<script src="assets/libs/swiper/swiper-bundle.min.js"></script>

<!-- Password Hide -->
<script src="assets/js/pages/password-addon.init.js"></script>

<!-- profile init js -->
<script src="assets/js/pages/profile.init.js"></script>
<script src="assets/js/pages/swiper.init.js"></script>
<!-- Sweet Alerts js -->
<script src="assets/libs/sweetalert2/sweetalert2.min.js"></script>



<!-- Sweet alert init js-->
<script src="assets/js/pages/sweetalerts.init.js"></script>
<!--datatable js-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script src="./assets/js/pages/jquery.dataTables.min.js"></script>
<script src="./assets/js/pages/dataTables.bootstrap5.min.js"></script>
<script src="./assets/js/pages/dataTables.responsive.min.js"></script>
<script src="./assets/js/pages/dataTables.buttons.min.js"></script>
<script src="./assets/js/pages/buttons.print.min.js"></script>
<script src="./assets/js/pages/buttons.html5.min.js"></script>
<script src="./assets/js/pages/vfs_fonts.js"></script>
<script src="./assets/js/pages/pdfmake.min.js"></script>
<script src="./assets/js/pages/jszip.min.js"></script>
<script src="./assets/js/pages/datatables.init.js"></script>
<!-- Modal Js -->
<script src="assets/js/pages/modal.init.js"></script>
<!-- prismjs plugin -->
<script src="assets/libs/prismjs/prism.js"></script>

<!-- gridjs js -->
<script src="assets/libs/gridjs/gridjs.umd.js"></script>
<!-- gridjs init -->
<script src="assets/js/pages/gridjs.init.js"></script>

<!-- swiper.init js -->
<script src="assets/js/pages/swiper.init.js"></script>
<!-- App js -->
<script src="assets/js/app.js"></script>






<script>
    // Empty Table Text
    function changeText() {
        var hide_data = document.querySelector('.dataTables_empty');
        if (hide_data) {
            hide_data.textContent = 'No Orders are available';
        }
    }

    var observer = new MutationObserver(function (mutationsList) {
        for (var mutation of mutationsList) {
            if (mutation.addedNodes.length > 0) {
                changeText();
                break;
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    window.onload = function () {
        changeText(); // Run the function once in case the element is already present
    };
 </script>

</body>

</html>