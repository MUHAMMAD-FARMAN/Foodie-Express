<?php
session_start();
require_once("database.php");

if (!isset($_SESSION['admin_email'])) {
    echo "<script>location='sign-in.php'</script>";
}

$email = $_SESSION['admin_email'];

$query = "SELECT * from admins where  email='$email'";
$admin = db::getRecord($query);
$profile_image = $admin['image_name'];

$query = "SELECT * from logo where id='1'";
$logo = db::getRecord($query);
$logo_image = $logo['logo_name'];




?>

<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none" data-preloader="disable">

<head>
    <meta charset="utf-8" />
    <title>Admin - Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--datatable css-->

    <link rel="stylesheet" href="./assets/css/dataTables.bootstrap5.min.css" />
    <!--datatable responsive css-->

    <link rel="stylesheet" href="./assets/css/responsive.bootstrap.min.css" />
    <link rel="stylesheet" href="./assets/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />


    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- swiper css -->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="./assets/ckeditor/sample/css/sample.css">
    <!-- SweetAlert -->
    <link href="assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />

    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />


   

    <!-- custom Css-->

    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.ckeditor.com/ckeditor5/38.1.1/super-build/ckeditor.js"></script>

</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <header id="page-topbar">
            <div class="layout-width">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box horizontal-logo mt-5"  style="max-width: 250px;">
                            <a href="index.php" class="logo logo-dark">
                                <span class="logo-sm">
                                    <img src="./uploads/logo/<?php echo $logo_image; ?>" height="30" width="30" alt="">

                                </span>
                                <span class="logo-lg">
                                    <img src="./uploads/logo/<?php echo $logo_image; ?>" height="80" width="50" alt="">

                                </span>
                            </a>

                            <a href="index.php" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="./uploads/logo/<?php echo $logo_image; ?>" height="30" width="30" alt="">
                                </span>
                                <span class="logo-lg">
                                    <img src="./uploads/logo/<?php echo $logo_image; ?>" height="80" width="50" alt="">
                                </span>
                            </a>
                        </div>

                        <button type="button"
                            class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger"
                            id="topnav-hamburger-icon">
                            <span class="hamburger-icon">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </button>


                    </div>

                    <div class="d-flex align-items-center">

                        <div class="dropdown d-md-none topbar-head-dropdown header-item">

                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                aria-labelledby="page-header-search-dropdown">
                                <form class="p-3">
                                    <div class="form-group m-0">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search ..."
                                                aria-label="Recipient's username">
                                            <button class="btn btn-primary" type="submit"><i
                                                    class="mdi mdi-magnify"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>






                        <div class="dropdown ms-sm-3 header-item topbar-user">
                            <button type="button" class="btn" id="page-header-user-dropdown" data-bs-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <span class="d-flex align-items-center">
                                    <img class="rounded-circle header-profile-user"
                                        src="./uploads/profile/<?php echo $profile_image ?>" alt="Header Avatar">
                                    <span class="text-start ms-xl-2">
                                        <span
                                            class="d-none d-xl-inline-block ms-1 fw-medium user-name-text">Admin</span>
                                    </span>
                                </span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                                <h6 class="dropdown-header">Welcome Admin!</h6>
                                <a class="dropdown-item" href="profile.php"><i
                                        class="mdi mdi-account-circle text-muted fs-16 align-middle me-1"></i> <span
                                        class="align-middle">Profile</span></a>


                                <form action="./action.php" method="post">
                                    <button class="dropdown-item" type="submit" name="logout"> <i
                                            class="mdi mdi-logout text-muted fs-16 align-middle me-1"></i> <span
                                            class="align-middle">Log Out</span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>




        <!-- ========== App Menu ========== -->
        <div class="app-menu navbar-menu">
            <!-- LOGO -->
            <div class="navbar-brand-box" style="max-width: 250px;">
                <!-- Dark Logo-->
                <a href="index.php" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="./uploads/logo/<?php echo $logo_image; ?>" height="30" width="30" alt="">

                    </span>
                    <span class="logo-lg">
                        <img src="./uploads/logo/<?php echo $logo_image; ?>" height="80" width="50" alt="">

                    </span>
                </a>
                <!-- Light Logo-->
                <a href="index.php" class="logo logo-light">
                    <span class="logo-sm" >
                        <img src="./uploads/logo/<?php echo $logo_image; ?>" class="w-100"   alt="">

</span>
                    <span class="logo-lg" style="max-width: 10px;">
                        <img class="w-100"   src="./uploads/logo/<?php echo $logo_image; ?>"  alt="">

                    </span>
                </a>
                <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                    id="vertical-hover">
                    <i class="ri-record-circle-line"></i>
                </button>
            </div>

            <div id="scrollbar">
                <div class="container-fluid">

                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="dashboard.php">
                                <i class="bx bxs-dashboard"></i> <span data-key="t-dashboards">Dashboard</span>
                            </a>

                        </li> 
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="logo.php">
                                <i class="bx bxs-image"></i> <span data-key="t-dashboards">Logo</span>
                            </a>

                        </li> 

                        <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="./banner.php">
                                <i class="bx bx-layout"></i> <span data-key="t-layouts">Banners</span>
                            </a>

                        </li>  -->

                        <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="./about.php">
                                <i class="bx bx-news"></i> <span data-key="t-layouts">About Us</span>
                            </a>

                        </li>  -->
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarMultilevel_category" data-bs-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="sidebarMultilevel_category">
                                <i class="bx bx-layer"></i> <span>Categories</span>
                            </a>
                            <div class="menu-dropdown collapse " id="sidebarMultilevel_category">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="categories.php" class="nav-link" ><i
                                                class="bx bx-layer"></i> <span> Categories</span> </a>
                                    </li>
                                    <li class="nav-item">
                                    <a href="sub-categories.php" class="nav-link" ><i class='bx bx-window' ></i><span> Sub Categories</span> </a>
                                    </li>
                                   

                                </ul>
                            </div>
                        </li>
                     
                     
                 
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="./products.php">
                                <i class="ri-shopping-basket-line"></i> <span data-key="t-apps">Products</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="orders.php" role="button" aria-expanded="false" "="">
                                <i class="bx bx-cube"></i> <span>Orders</span>
                            </a>
                         
                        </li>
                    </ul>
                </div>
                <!-- Sidebar -->
            </div>

        
            <div class="sidebar-background"></div>
        </div>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>



        <!-- END layout-wrapper -->