<?php 
    echo "<script>location='dashboard.php '</script>"; 
    ?>