<?php include('header.php'); 


$query = "SELECT * from logo where id='1'";
$logo = db::getRecord($query);
$logo_image = $logo['logo_name'];


?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">

                        <h3 class="text-center text-white my-2">Logo</h3>
                    </div>
                </div>
            </div>
            <div class="row my-5">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="./dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Logo</li>
                        </ol>
                    </div>
                </div>
            </div>


            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-center">Update Logo</h2>
                        </div>
                        <form action="action.php" method="post" enctype="multipart/form-data" >
                        <div class="card-body d-flex flex-column align-items-center">
                            <div class="m-auto" >
                            <img width="300"  height="300" class='rounded-4 w-100' src="./uploads/logo/<?php echo $logo_image; ?>" alt="">

                            </div>
                            <div class="my-3 text-center">
                                <label for="logo" class="form-label fs-5 ">Update Logo</label>
                                <input type="file" required class="form-control" name="logo" id="logo">
                            </div>
                            <div class="my-3 text-center">
                            <button type="submit" class="btn  btn-lg btn-success"
                                        name="update_logo">Update</button>                            </div>

                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <footer class="footer ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <p>&copy; Copyright
                        <script>
                        document.write(new Date().getFullYear());
                        </script> Single Solution.
                    </p>
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        <p> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- end main content-->




<?php include('footer.php'); ?>