<?php
require_once('../database.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';



if (isset($_POST['send']))
{
    $nameForm=$_POST['name'];
    $emailForm=$_POST['email'];
    $numberForm=$_POST['number'];
    $subjectForm=$_POST['subject'];
    $messageForm=$_POST['message'];  

    $mail = new PHPMailer();



    //For Client Server

    // $mail->isSMTP();
    // $mail->Host = 'mail.paramountmedicalcenter.ae';
    // $mail->SMTPAuth = true;
    // $mail->Username = 'test@paramountmedicalcenter.ae';
    // $mail->Password = 'Admin@123!';
    // $mail->SMTPSecure = 'tls';
    // $mail->Port = 465;
    // $mail->setFrom('test@paramountmedicalcenter.ae', 'Paramount');
    // $mail->addAddress('haiderduraiz@gmail.com', 'Duraiz123');



    //For Gmail

    //$mail->isSMTP();
    //$mail->Host = 'smtp.gmail.com';
    //$mail->SMTPAuth = true;
    //$mail->Username = 'singlesolution.email.sender@gmail.com';
    //$mail->Password = 'ynyzwxoiqqvpmjmi';
    //$mail->SMTPSecure = 'tls';
    //$mail->Port = 587;
    //$mail->setFrom('singlesolution.email.sender@gmail.com', 'Ali,Tamoor,Duraiz');
    //$mail->addAddress('haiderduraiz@gmail.com', 'Duraiz123');


    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'singlesolution.email.sender@gmail.com';
    $mail->Password = 'ynyzwxoiqqvpmjmi';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->setFrom('singlesolution.email.sender@gmail.com', 'Single Solution');
    $mail->addAddress('muhammadsuheer6@gmail.com', 'Ali Usman');




    $mail->Subject = 'Subject Line123';
    $mail->Body = 'Email body123';



    $html = file_get_contents('contact.html');

    $html = str_replace('{{name}}', $nameForm, $html);
    $html = str_replace('{{email}}', $emailForm, $html);
   $html = str_replace('{{number}}', $numberForm, $html);
   $html = str_replace('{{subject}}', $subjectForm, $html);
   $html = str_replace('{{message}}', $messageForm, $html);
    $mail->msgHTML($html);




    if(!$mail->send()) {
        echo 'Mailer Error: ' . $mail->ErrorInfo;        
        echo "<script>location='../../contact.php?status=1'</script>";
    } else {
         echo "<script>location='../../index.php?status=5'</script>";
    }
   }























if (isset($_POST['forget_password'])) {
    $db = db::open();
$user_email = $db->real_escape_string($_POST['email']);
$query = "SELECT * FROM admins WHERE email = '$user_email' ORDER BY id DESC LIMIT 1";
$query_response = db::getRecord($query);
    if ($query_response != NULL) {
        $first_name = $query_response['first_name'];
        $last_name = $query_response['last_name'];
        $username = strtolower($first_name . $last_name);
        $code = mt_rand(111111, 999999);
        $query = "INSERT INTO verify_code (email,code) VALUES ('$user_email','$code')";
        $inserted = db::query($query);
        if($inserted) {
               $mail = new PHPMailer();

        // $mail->isSMTP();
        // $mail->Host = 'mail.paramountmedicalcenter.ae';
        // $mail->SMTPAuth = true;
        // $mail->Username = 'test@paramountmedicalcenter.ae';
        // $mail->Password = 'Admin@123!';
        // $mail->SMTPSecure = 'tls';
        // $mail->Port = 465;
        // $mail->setFrom('test@paramountmedicalcenter.ae', 'Paramount');
        // $mail->addAddress('haiderduraiz@gmail.com', 'Duraiz123');

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'singlesolution.email.sender@gmail.com';
        $mail->Password = 'ynyzwxoiqqvpmjmi';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('singlesolution.email.sender@gmail.com', 'Company Name');
        // $mail->addAddress($user_email, $user_username);
        $mail->addAddress("$user_email", "$username");




        $mail->Subject = 'Password Reset Request';
        // $mail->Body = 'Email body123';



        $html = file_get_contents('reset_password.html');
        $mail->isHTML(true);
        $mail->Body = $html;

        $html = str_replace('{{user}}', "$username", $html);
        $html = str_replace('{{brand_name}}', "Brand Name", $html);
        $html = str_replace('{{email}}', "$user_email", $html);
        $html = str_replace('{{code}}', "$code", $html);
        $html = str_replace('{{link}}', "https://dev.single-solution.com/shabo_v11/admin/verify-code.php?email=$user_email", $html);
        $html = str_replace('{{link1}}', "https://dev.single-solution.com/shabo_v11/admin/verify-code.php?code=$code&email=$user_email", $html);


        $mail->msgHTML($html);




        if (!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            $status = 4;
            header("Location: ../verify_message.php?status=" . urlencode($status) . "&email=" . urlencode($user_email));
        }
    } else {
        $status = 5;
        echo '<script>location="../forget-password.php?status=' . urlencode($status) . '"</script>';
    }
        }
     
}




if (isset($_POST['user_forget_password'])) {
    $db = db::open();
$user_email = $db->real_escape_string($_POST['email']);
$query = "SELECT * FROM user_login WHERE email = '$user_email' ORDER BY id DESC LIMIT 1";
$query_response = db::getRecord($query);
    if ($query_response != NULL) {
        $username = strtolower($query_response['full_name']);
        $code = mt_rand(111111, 999999);
        $query = "INSERT INTO verify_code (email,code) VALUES ('$user_email','$code')";
        $inserted = db::query($query);
    
        $mail = new PHPMailer();

        // $mail->isSMTP();
        // $mail->Host = 'mail.paramountmedicalcenter.ae';
        // $mail->SMTPAuth = true;
        // $mail->Username = 'test@paramountmedicalcenter.ae';
        // $mail->Password = 'Admin@123!';
        // $mail->SMTPSecure = 'tls';
        // $mail->Port = 465;
        // $mail->setFrom('test@paramountmedicalcenter.ae', 'Paramount');
        // $mail->addAddress('haiderduraiz@gmail.com', 'Duraiz123');

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'singlesolution.email.sender@gmail.com';
        $mail->Password = 'ynyzwxoiqqvpmjmi';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('singlesolution.email.sender@gmail.com', 'Shabo');
        // $mail->addAddress($user_email, $user_username);
        $mail->addAddress("$user_email", "$username");




        $mail->Subject = 'Password Reset Request';
        // $mail->Body = 'Email body123';



        $html = file_get_contents('reset_password.html');
        $mail->isHTML(true);
        $mail->Body = $html;

        $html = str_replace('{{user}}', "$username", $html);
        $html = str_replace('{{brand_name}}', "Shabo", $html);
        $html = str_replace('{{email}}', "$user_email", $html);
        $html = str_replace('{{code}}', "$code", $html);
        $html = str_replace('{{link}}', "https://dev.single-solution.com/shabo_v11/verify-password.php?email=$user_email", $html);
        $html = str_replace('{{link1}}', "https://dev.single-solution.com/shabo_v11/verify-password.php?code=$code&email=$user_email", $html);


        $mail->msgHTML($html);




        if (!$mail->send()) {
            echo 'Message could not be sent.'; 
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            $status = 4;
            header("Location: ../../verify_message.php?status=" . urlencode($status) . "&email=" . urlencode($user_email));
        }
    } else {
        $status = 5;
        echo '<script>location="../../forget-password.php?status=' . urlencode($status) . '"</script>';
    }
}










if (isset($_POST['sign_up_verify'])) {
    $db = db::open();

    $full_name = $db->real_escape_string($_POST['full_name']);
    $user_email = $db->real_escape_string($_POST['email']);
    $phone = $db->real_escape_string($_POST['phone']);
    $password = $db->real_escape_string($_POST['password']);
    $confirm_password = $db->real_escape_string($_POST['confirm_password']);
    $address = $db->real_escape_string($_POST['address']);
    $city = $db->real_escape_string($_POST['city']);
    $country = $db->real_escape_string($_POST['country']);
    $postal_code = $db->real_escape_string($_POST['postal_code']);

    $query = "SELECT  email from user_login  WHERE email = '$user_email'";
    $user_mails = db::getRecord($query);

   if(!empty($user_mails)) {
    $status = 1;
    header("Location: ../../register.php?status=" . $status);
    exit();
   }
    if ($password == $confirm_password) {
        $options = ['cost' => 12];
        $hash_password = password_hash($password, PASSWORD_DEFAULT, $options);
    } else {
        $status = 2;
        header("Location: ../../register.php?status=" . $status);
        exit();
    }

    $query = "INSERT INTO user_login (full_name, email, phone, password, address, city, country, postal_code) 
              VALUES ('$full_name', '$user_email', '$phone', '$hash_password', '$address', '$city', '$country', '$postal_code')";
    $insert = db::query($query);


    
    $query = "SELECT * FROM user_login WHERE email = '$user_email' ORDER BY id DESC LIMIT 1";
    $query_response = db::getRecord($query);
      if ($query_response != NULL) {
         $username = strtolower($query_response['full_name']);
         $code = mt_rand(111111, 999999);
         $query = "INSERT INTO verify_code (email,code) VALUES ('$user_email','$code')";
         $inserted = db::query($query);

        $mail = new PHPMailer();

        // $mail->isSMTP();
        // $mail->Host = 'mail.paramountmedicalcenter.ae';
        // $mail->SMTPAuth = true;
        // $mail->Username = 'test@paramountmedicalcenter.ae';
        // $mail->Password = 'Admin@123!';
        // $mail->SMTPSecure = 'tls';
        // $mail->Port = 465;
        // $mail->setFrom('test@paramountmedicalcenter.ae', 'Paramount');
        // $mail->addAddress('haiderduraiz@gmail.com', 'Duraiz123');

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'singlesolution.email.sender@gmail.com';
        $mail->Password = 'ynyzwxoiqqvpmjmi';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('singlesolution.email.sender@gmail.com', 'Shabo');
        // $mail->addAddress($user_email, $user_username);
        $mail->addAddress("$user_email", "$username");




        $mail->Subject = 'Verify Your Email';
        // $mail->Body = 'Email body123';



        $html = file_get_contents('email_verified.html');
        $mail->isHTML(true);
        $mail->Body = $html;

        $html = str_replace('{{user}}', "$username", $html);
        $html = str_replace('{{brand_name}}', "User", $html);
        $html = str_replace('{{email}}', "$user_email", $html);
        $html = str_replace('{{code}}', "$code", $html);
        $html = str_replace('{{link}}', "https://dev.single-solution.com/shabo_v11/verify-code.php?email=$user_email", $html);
        $html = str_replace('{{link1}}', "https://dev.single-solution.com/shabo_v11/verify-code.php?code=$code&email=$user_email", $html);


        $mail->msgHTML($html);




        if (!$mail->send()) {
            echo 'Message could not be sent.'; 
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            $status = 4;
            header("Location: ../../verify_message.php?status=" . urlencode($status) . "&email=" . urlencode($user_email));
        }
    } else {
        $status = 5;
        echo '<script>location="../../index.php?status=' . urlencode($status) . '"</script>';
    }
}



?>