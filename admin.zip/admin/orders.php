<?php include('header.php');


$query = "SELECT *  from orders ORDER BY id DESC";
$orders = db::getRecords($query);
?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">

                        <h3 class="text-center text-white my-2">Orders</h3>
                    </div>
                </div>
            </div>
<div class="row my-5">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="./dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Orders</li>
                        </ol>
                       
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">
                            <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12" id="show_table">
                                    <table id="fixed-header"
                                        class="table table-bordered dt-responsive nowrap table-striped align-middle dataTable no-footer dtr-inline"
                                        style="width: 100%;" aria-describedby="fixed-header_info">
                                        <thead>

                                            <tr>
                                                <th scope="col" style="width: 16.8px;" class="sorting sorting_asc"
                                                    tabindex="0" aria-controls="example" rowspan="1" colspan="1"
                                                    aria-sort="ascending" aria-label="
                                                    
                                                        
                                                    
                                                : activate to sort column descending">
                                                    <div class="form-check">
                                                        <input class="form-check-input fs-15" type="checkbox"
                                                            id="checkAll" value="option">
                                                    </div>
                                                </th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 83.6px;"
                                                    aria-label="SR No.: activate to sort column ascending">SR No.</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 71.6px;"
                                                    aria-label="ID: activate to sort column ascending">User Name</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 145.6px;"
                                                    aria-label="Purchase ID: activate to sort column ascending">Phone
                                                </th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 397.6px;"
                                                    aria-label="Title: activate to sort column ascending">Email</th>

                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 137.6px;"
                                                    aria-label="Assigned To: activate to sort column ascending">Total
                                                    Products</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 128.6px;"
                                                    aria-label="Created By: activate to sort column ascending">Total
                                                    Bill</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 88.6px;"
                                                    aria-label="Status: activate to sort column ascending">Order Status
                                                </th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 85.6px;"
                                                    aria-label="Action: activate to sort column ascending">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            if (!empty($orders)) {
                                                $key =1;

                                                foreach ($orders as $order)
                                            
                                                
                                                
                                                {
                                                    if ($order['payment_status'] == 0) {
                                                        $order_status = "Unpaid";
                                                    }
                                                    ?>
                                            <tr class="odd">
                                                <th scope="row" class="dtr-control sorting_1" tabindex="0">
                                                    <div class="form-check">
                                                        <input class="form-check-input fs-15" type="checkbox"
                                                            name="checkAll" value="option1">
                                                    </div>
                                                </th>
                                                <td>
                                                    <?php echo $key ;?>
                                                </td>
                                                <td>
                                                    <?php echo $order['full_name'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $order['phone'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $order['email'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $order['total_products'] ?>
                                                </td>
                                                <td>
                                                    $<?php echo $order['total_bill'] ?>
                                                </td>
                                              
                                                <td><span class="badge  <?php if ($order['payment_status'] == 1) {
                                                            echo 'badge-soft-info';
                                                        } else {
                                                            echo 'badge-soft-success';
                                                        } ?> fs-6">
                                                        <?php if ($order['payment_status'] == 1) {
                                                                    echo 'Completed';
                                                                } else {
                                                                    echo 'Active';
                                                                } ?>
                                                    </span></td>
                                                <td>
                                                    <div class="dropdown d-inline-block">
                                                        <button class="btn btn-soft-secondary btn-sm dropdown"
                                                            type="button" data-bs-toggle="dropdown"
                                                            aria-expanded="false">
                                                            <i class="ri-more-fill align-middle"></i>
                                                            &nbsp;Actions
                                                        </button>
                                                        <ul class="dropdown-menu dropdown-menu-end">
                                                            <?php if ($order['payment_status'] == 0) { ?>
                                                            <li><a type="button"
                                                                    onclick="view_modal(<?php echo $order['order_id'] ?>)"
                                                                    class="dropdown-item"><i
                                                                        class="ri-eye-fill align-bottom me-2 text-muted"></i>
                                                                    View Details</a></li>


                                                            <li>
                                                                <button type="button"
                                                                    onclick="order_paid_modal('<?php echo $order['order_id'] ?>')"
                                                                    class="dropdown-item remove-item-btn">
                                                                    <i
                                                                        class="ri-secure-payment-fill align-bottom me-2 text-muted"></i>
                                                                    Mark As Complete
                                                                </button>
                                                            </li>

                                                            <li>
                                                                <button type="button"
                                                                    onclick="order_delete_modal('<?php echo $order['order_id'] ?>')"
                                                                    class="dropdown-item remove-item-btn">
                                                                    <i
                                                                        class="ri-delete-bin-fill align-bottom me-2 text-muted"></i>
                                                                    Delete
                                                                </button>
                                                            </li>

                                                            <?php        } else {?>
                                                            <li><a type="button"
                                                                    onclick="view_modal(<?php echo $order['order_id'] ?>)"
                                                                    class="dropdown-item"><i
                                                                        class="ri-eye-fill align-bottom me-2 text-muted"></i>
                                                                    View Details</a></li>




                                                            <li>
                                                                <button type="button"
                                                                    onclick="order_delete_modal('<?php echo $order['order_id'] ?>')"
                                                                    class="dropdown-item remove-item-btn">
                                                                    <i
                                                                        class="ri-delete-bin-fill align-bottom me-2 text-muted"></i>
                                                                    Delete
                                                                </button>
                                                            </li>

                                                            <?php    } ?>

                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php 
                                                    
                                                        $key ++;
                                                }
                                            } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
    </div>
    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <footer class="footer ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <p>&copy; Copyright
                        <script>
                        document.write(new Date().getFullYear());
                        </script> Single Solution.
                    </p>
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        <p> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- end main content-->

</div>
<!-- END layout-wrapper -->
</div>

<!-- Theme Settings -->



<div id='paid-modal' class='modal fade' aria-labelledby='delete-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                <h2 class='text-white'>Mark As Paid </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class='modal-body '>
                <div class='mt-3 text-center mx-lg-3'>
                    <lord-icon     src="https://cdn.lordicon.com/lupuorrc.json"
 trigger='loop'
 colors="primary:#121331,secondary:#08a88a"
 style='width:100px;height:100px'></lord-icon>
                    <div class='mt-4'>
                        <h4>Are you Sure ?</h4>
                        <p class='text-muted mt-3 mb-0'>Are you Sure You want to Mark This Order As Complete ?</p>
                        <form action="action.php" method="post">
                            <div class='d-flex justify-content-between  mt-4 mx-md-5'>

                                <input id="order_paid_id" name="order_id" type="hidden">
                          
                                <button type='button' class='btn btn-light  bg-gradient waves-effect waves-light'
                                    data-bs-dismiss='modal'>Cancel</button>
                                    <button type='submit' name="mark_as_paid"
                                    class='btn btn-success  bg-gradient waves-effect waves-light'>Yes
                                    Mark As Complete
                                </button>   
                        </form>
                    </div>
                </div>
            </div>

             
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


</div>
<div id='view-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered modal-fullscreen modal-backdrop'>
        <div class='modal-content border-0 border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 '>
                <h2 class='text-black'>Order Details</h2>
                <button type='button' class='btn-close btn-lg  mt-n2 opacity-100  waves-light btn-lg '
                    data-bs-dismiss='modal' aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5' id="order_show">



                <div class='heading my-3 float-end'>
                    <button type='button' data-bs-dismiss="modal"
                        class='btn btn-light waves-effect waves-light btn-lg btn-block'>Close</button>
                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>


<div id='delete-modal' class='modal fade' aria-labelledby='delete-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-danger '>
                <h2 class='text-white'>Delete </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class='modal-body '>
                <div class='mt-3 text-center'>
                    <lord-icon src='https://cdn.lordicon.com/gsqxdxog.json' trigger='loop'
                        colors='primary:#f7b84b,secondary:#f06548' style='width:100px;height:100px'></lord-icon>
                    <div class='mt-4 pt-2 fs-15 mx-5'>
                        <h4>Are you Sure ?</h4>
                        <p class='text-muted mx-4 mb-0'>Are you Sure You want to Delete this product ?</p>
                        <form action="action.php" method="post">
                            <div class='d-flex justify-content-between  mt-4 mx-md-5'>

                                <input id="order_delete_id" name="order_id" type="hidden">
                                <button type='submit' name="delete_order"
                                    class='btn btn-danger  bg-gradient waves-effect waves-light'>Yes
                                    Delete
                                    It</button>
                                <button type='button' class='btn btn-primary  bg-gradient waves-effect waves-light'
                                    data-bs-dismiss='modal'>Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->








<!-- JAVASCRIPT -->
<script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
<script src='assets/libs/simplebar/simplebar.min.js'></script>
<script src='assets/libs/node-waves/waves.min.js'></script>
<script src='assets/libs/feather-icons/feather.min.js'></script>
<script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
<script src='assets/js/plugins.js'></script>
<!-- Sweet Alerts js -->
<script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

<!-- Sweet alert init js-->
<script src='assets/js/pages/sweetalerts.init.js'></script>
<!-- calendar min js -->
<script src='assets/libs/fullcalendar/main.min.js'></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!-- Calendar init -->
<script src='assets/js/pages/calendar.init.js'></script>
<script src="./assets/js/pages/jquery.dataTables.min.js"></script>
<script src="./assets/js/pages/dataTables.bootstrap5.min.js"></script>
<script src="./assets/js/pages/dataTables.responsive.min.js"></script>
<script src="./assets/js/pages/dataTables.buttons.min.js"></script>
<script src="./assets/js/pages/buttons.print.min.js"></script>
<script src="./assets/js/pages/buttons.html5.min.js"></script>
<script src="./assets/js/pages/vfs_fonts.js"></script>
<script src="./assets/js/pages/pdfmake.min.js"></script>
<script src="./assets/js/pages/jszip.min.js"></script>
<script src="./assets/js/pages/datatables.init.js"></script>
<!-- App js -->
<script src='assets/js/app.js'></script>
<script>
function view_modal(order_id) {

    $.ajax({
        url: "assets/ajax/order-view-details.php",
        type: "POST",
        data: {
            order_id: order_id,
        },
        success: function(response) {
            $("#order_show").html(response);
        },
    });
    $("#view-modal").modal('show');
}

function order_paid_modal(id) {
    document.getElementById('order_paid_id').value = id;
    $("#paid-modal").modal('show');
}

function order_delete_modal(id) {
    document.getElementById('order_delete_id').value = id;
    $("#delete-modal").modal('show');


}
</script>


<script>
const urlParams = new URLSearchParams(window.location.search);


if (urlParams.get('status') === '1') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4>Mark As Complete</h4><p class="text-muted mx-4 mb-0">Order has Been Successfully Mark as Complete</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}

if (urlParams.get('status') === '2') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Order Deleted</h4><p class="text-muted mx-4 mb-0">Order Has Been Successfully Deleted</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
if (urlParams.get('status') === '3') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Banner Updated</h4><p class="text-muted mx-4 mb-0">Banner Have Been Successfully Updated</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
</script>   