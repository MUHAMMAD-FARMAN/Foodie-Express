<?php include('header.php');


$db = db::open();
$query = "SELECT * from products ORDER BY id DESC";
$products = db::getRecords($query);


$query = "SELECT *  from sub_categories";
$sub_categories = db::getRecords($query);

$query = "SELECT *  from categories";
$categories = db::getRecords($query);



?>
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">

                        <h3 class="text-center text-white my-2">Products</h3>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="./dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Products</li>
                        </ol>
                        <div class="page-title-right">
                            <button type='button' class='btn custom-gradient    text-white  fs-7 '
                                data-bs-toggle='modal' data-bs-target='#add-product'>Add New Product</button>
                        </div>
                    </div>
                </div>
            </div>


            <div class='row mt-5'>

                <?php
                if ($products != Null) {
                    foreach ($products as $product) {
                        $id = $product['id'];
                        $query = "SELECT * from product_images where product_id='$id'";
                        $product_images = db::getRecords($query);
                        $product_id = $product['id'];

                        ?>
                <div class="col-md-4  col-sm-6 col-lg-3  my-3">
                    <div class="card" style="width:100%; height: 95%;">

                        <!-- Individual Slide -->

                        <div class="card-body">


                            <div class="swiper navigation-swiper rounded">
                                <div class="swiper-wrapper">
                                    <?php
                                            if ($product_images != NULL) {
                                                foreach ($product_images as $product_image_name) { ?>

                                    <div class="swiper-slide">
                                        <img src="<?php echo "./uploads/products/" . $product_image_name['product_image_name']; ?>"
                                            alt="" class="img-fluid  w-100 h-300px" />
                                    </div>
                                    <?php
                                                }
                                            }
                                            ?>


                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                            </div>



                        </div>
                        <div class="card-body d-flex align-items-end justify-content-center ">
                            <h5 class="text-center ellipsis h-30" style="max-width: 100%;">
                                <?php echo $product['product_title']; ?>
                            </h5>
                        </div>
                        <div class='card-footer pt-4  d-flex justify-content-between text-center'>
                            <button type='button'
                                class='btn btn-primary btn-xl d-flex justify-content-center align-items-center waves-effect waves-light'
                                onclick="view_modal('<?php echo $product_id ?>')"><i class='fas fa-eye'></i></button>
                            <a type='button' href="./edit-products.php?id=<?php echo $product_id ?>"
                                class='btn btn-success mx-3 d-flex justify-content-center align-items-center
                                                               d-flex justify-content-center align-items-center waves-effect waves-light'><i class='fa fa-pencil'>
                                </i></a>
                            <button type='button'
                                class='btn btn-danger btn-xl d-flex justify-content-center align-items-center waves-effect waves-light'
                                onclick="delete_modal('<?php echo $product['id']; ?>')"><i
                                    class='fas fa-trash'></i></button>
                        </div>
                    </div>
                </div>
                <?php }
                }

                ?>

            </div>



        </div>
    </div>
</div>


 <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <footer class="footer ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <p>&copy; Copyright
                        <script>
                        document.write(new Date().getFullYear());
                        </script> Single Solution.
                    </p>
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        <p> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- end main content-->



<div id='view-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered modal-xl'>
        <div class='modal-content border-0 border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-primary '>
                <h2 class='text-white'>View Details</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class='modal-body py-3 px-5' id="view_modal_data" style="min-height: 50vh;">

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>

<div id='add-product' class='modal fade' aria-labelledby='add-product' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered  modal-xl'>
        <div class='modal-content border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-primary '>
                <h2 class='text-white'>Add Product</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class='modal-body py-3 px-5'>
                <form action='action.php' enctype="multipart/form-data" method='post'>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="category_id" class="lead">Category</label>
                                <select class="select2-selection select2-selection--single form-control"
                                    name="category_id" id="add_select_category" required onchange=change_sub_category(this)>
                                    <option></option>

                                    <?php foreach ($categories as $category) { ?>
                                    <option value="<?php echo $category['id']; ?>"><?php echo $category['title']; ?>
                                    </option>
                                    <?php } ?>
                                </select>

                            </div>


                            <div class="mb-3" id="sub_categories_edit">

                            </div>

                            <div class='mb-3'>
                                <label for='product_images' class='form-label fs-4'>Product Images</label>
                                <input type='file' multiple class='form-control' name="product_images[]"
                                    id='product_images' required>
                            </div>
                            <div class='heading my-3'>
                                <div class='mb-3'>
                                    <label for='product_name' class='form-label fs-4'>Product Price</label>
                                    <div class="input-group">
                                        <span class="input-group-text">$</span>
                                        <input type="number" min="1" required class="form-control" name="product_price">
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <!-- <div class="col-sm-6">
                                    <div class='heading my-3'>
                                        <div class='mb-3'>
                                            <label for='product_stock' class='form-label fs-4'>Out Of Stock</label>
                                            <div class="form-check form-switch form-switch-lg" dir="ltr">
                                                <input type="checkbox" name="product_stock" id="product_stock"
                                                    class="form-check-input" class="customSwitchsizelg" value="1">

                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                                <div class="col-sm-12">

                                    <div class='heading my-3'>
                                        <div class='mb-3'>
                                            <label for='product_feature' class='form-label fs-4'>Feature The
                                                Product</label>
                                            <div class="form-check form-switch form-switch-lg" dir="ltr">
                                                <input type="checkbox" name="product_feature" id="product_feature"
                                                    class="form-check-input" class="customSwitchsizelg" value="1">
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class='heading my-3'>
                                <div class='mb-3'>
                                    <label for='product_name' class='form-label fs-4'>Product Name</label>
                                    <input type='text' class='form-control' name='product_name' id='product_name'
                                        placeholder='Enter Product Name' required>
                                </div>

                            </div>
                            <div class='heading my-3'>
                                <div class='mb-3'>
                                    <label for='product_description' class='form-label fs-4'>Enter Product
                                        Short Description</label>
                                    <textarea name="product_description_short" required class="form-control"
                                        id="product_description" rows="8"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">


                            <div class='heading my-3'>
                                <div class='mb-3'>
                                    <label for='product_description' required class='form-label fs-4'>Enter Product
                                        Long Description</label>
                                    <textarea name="product_description" id="editor" rows="4"></textarea>
                                </div>
                            </div>


                        </div>

                    </div>
                    <div class='d-flex justify-content-between  mt-4 mx-md-5'>


                        <button type='button' class='btn btn-light btn-lg  waves-effect waves-dark'
                            data-bs-dismiss='modal'>Cancel</button>
                        <button type='submit' name='add-product'
                            class='btn btn-primary btn-lg waves-effect waves-light'>Add
                            Product</button>
                    </div>
                </form>
            </div><!-- /.modal-body -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /#add-product -->


<div id='edit-modal' class='modal fade' aria-labelledby='edit-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                <h2 class='text-white'>Edit Details</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <form action="action.php" id="edit_form" method="post" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label for="formSizeDefault" class="form-label"> Edit Product Image</label>
                        <input class="form-control" id="sub_edit_file" type="file" name="image_update[]" multiple>
                    </div>

                    <div class="edit_content_div">
                    </div>
                    <input type="hidden" id="product_id" name="id">

                    <div class="text-end">
                        <button type="submit" class="btn btn-success" name="update_product">Update</button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
</div>


<div id='delete-modal' class='modal fade' aria-labelledby='delete-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-danger '>
                <h2 class='text-white'>Delete </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-header'>

            </div>
            <div class='modal-body '>
                <div class='mt-3 text-center mx-lg-3'>
                    <lord-icon src='https://cdn.lordicon.com/gsqxdxog.json' trigger='loop'
                        colors='primary:#f7b84b,secondary:#f06548' style='width:100px;height:100px'></lord-icon>
                    <div class='text-muted mt-3 mb-0'>
                        <h4>Are you Sure ?</h4>
                        <p class='text-muted mx-4 mb-0'>Are you Sure You want to Delete this product ?</p>
                        <form action="action.php" method="post">
                            <div class='d-flex justify-content-between  mt-4 mx-md-5'>

                                <input id="delete_product_id" type="hidden" name="product_id">

                                <button type='button' class='btn btn-primary  waves-effect waves-light'
                                    data-bs-dismiss='modal'>Cancel</button>
                                <button type='submit' name="delete_product"
                                    class='btn btn-danger  waves-effect waves-light'>Yes
                                    Delete
                                    It</button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



















<!-- JAVASCRIPT -->

<script src="assets/libs/swiper/swiper-bundle.min.js"></script>
<script src="./assets/ckeditor/ckeditor.js"></script>

<!-- swiper.init js -->
<script src="assets/js/pages/swiper.init.js"></script>
<script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
<script src='assets/libs/simplebar/simplebar.min.js'></script>
<script src='assets/libs/node-waves/waves.min.js'></script>
<script src='assets/libs/feather-icons/feather.min.js'></script>
<script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
<script src='assets/js/plugins.js'></script>
<!-- Sweet Alerts js -->
<script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

<!-- Sweet alert init js-->
<script src='assets/js/pages/sweetalerts.init.js'></script>
<!-- calendar min js -->
<script src='assets/libs/fullcalendar/main.min.js'></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!-- Calendar init -->
<script src='assets/js/pages/calendar.init.js'></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>

<!-- App js -->
<script src='assets/js/app.js'></script>



<script>
    // This sample still does not showcase all CKEditor 5 features (!)
    // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
    CKEDITOR.ClassicEditor.create(document.getElementById("editor"), {
        // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
        toolbar: {
            items: [

                'link', 'findAndReplace', 'selectAll', '|',
                'heading', '|',
                'bold', 'italic', 'strikethrough', 'underline', 'code', 'subscript', 'superscript',
                'removeFormat', '|',
                'bulletedList', 'numberedList', 'todoList', '|',
                'outdent', 'indent', '|',
                'undo', 'redo',
                '-',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
                'alignment', '|',
                'link', 'blockQuote', 'insertTable',
                '|',
                'specialCharacters', 'horizontalLine', 'pageBreak', '|'
                , '|',
            ],
            shouldNotGroupWhenFull: true
        },
        // Changing the language of the interface requires loading the language file using the <script> tag.
        // language: 'es',
        list: {
            properties: {
                styles: true,
                startIndex: true,
                reversed: true
            }
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
        heading: {
            options: [{
                    model: 'paragraph',
                    title: 'Paragraph',
                    class: 'ck-heading_paragraph'
                },
                {
                    model: 'heading1',
                    view: 'h1',
                    title: 'Heading 1',
                    class: 'ck-heading_heading1'
                },
                {
                    model: 'heading2',
                    view: 'h2',
                    title: 'Heading 2',
                    class: 'ck-heading_heading2'
                },
                {
                    model: 'heading3',
                    view: 'h3',
                    title: 'Heading 3',
                    class: 'ck-heading_heading3'
                },
                {
                    model: 'heading4',
                    view: 'h4',
                    title: 'Heading 4',
                    class: 'ck-heading_heading4'
                },
                {
                    model: 'heading5',
                    view: 'h5',
                    title: 'Heading 5',
                    class: 'ck-heading_heading5'
                },
                {
                    model: 'heading6',
                    view: 'h6',
                    title: 'Heading 6',
                    class: 'ck-heading_heading6'
                }
            ]
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
        placeholder: 'Write Description',
        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
        fontFamily: {
            options: [
                'default',
                'Arial, Helvetica, sans-serif',
                'Courier New, Courier, monospace',
                'Georgia, serif',
                'Lucida Sans Unicode, Lucida Grande, sans-serif',
                'Tahoma, Geneva, sans-serif',
                'Times New Roman, Times, serif',
                'Trebuchet MS, Helvetica, sans-serif',
                'Verdana, Geneva, sans-serif'
            ],
            supportAllValues: true
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
        fontSize: {
            options: [10, 12, 14, 'default', 18, 20, 22],
            supportAllValues: true
        },
        // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
        // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
        htmlSupport: {
            allow: [{
                name: /.*/,
                attributes: true,
                classes: true,
                styles: true
            }]
        },
        // Be careful with enabling previews
        // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
       
        // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
        link: {
            addTargetToExternalLinks: true,
            decorators: {
                defaultProtocol: 'https://',
                toggleDownloadable: {
                    mode: 'manual',
                    label: 'Downloadable',
                    attributes: {
                        download: 'file'
                    }
                },
                openInNewTab: {
                    mode: 'manual',
                    label: 'Open in a new tab',
                    defaultValue: true, // This option will be selected by default.
                    attributes: {
                        target: '_blank',
                        rel: 'noopener noreferrer'
                    }
                }
            }
        },
        // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
       
        // The "super-build" contains more premium features that require additional configuration, disable them below.
        // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
        removePlugins: [
            // These two are commercial, but you can try them out without registering to a trial.
            // 'ExportPdf',
            // 'ExportWord',
            'CKBox',
            'CKFinder',
            'EasyImage',
            // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
            // Storing images as Base64 is usually a very bad idea.
            // Replace it on production website with other solutions:
            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
            // 'Base64UploadAdapter',
            'RealTimeCollaborativeComments',
            'RealTimeCollaborativeTrackChanges',
            'RealTimeCollaborativeRevisionHistory',
            'PresenceList',
            'Comments',
            'TrackChanges',
            'TrackChangesData',
            'RevisionHistory',
            'Pagination',
            'WProofreader',
            // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
            // from a local file system (file://) - load this site via HTTP server if you enable MathType.
            'MathType',
            // The following features are part of the Productivity Pack and require additional license.
            'SlashCommand',
            'Template',
            'DocumentOutline',
            'FormatPainter',
            'TableOfContents'
        ]
    });
    </script>

<script>
function change_sub_category(e) {
    const category_id = e.value;

    $.ajax({
        url: "assets/ajax/product_select_add.php",
        type: "POST",

        data: {
            category_id: category_id,
        },

        success: function(response) {

            $("#sub_categories_edit").html(response);


        },

    });



}



$("#add_select_category").select2({

    placeholder: 'Please Select a Category'
});



function edit_sub_category(e) {
    const category_id = e.value;

    $.ajax({
        url: "assets/ajax/product_select_edit.php",
        type: "POST",

        data: {
            category_id: category_id,
        },

        success: function(response) {

            $("#edit_sub_category_ajax").html(response);


        },

    });



}


$("#edit_select_category").select2({

    placeholder: 'Please Select a Category'
});





function add_modal(category_id) {

    var category_id = category_id;

    $.ajax({
        url: "assets/ajax/product_carousel_load.php",
        type: "POST",

        data: {
            product_id: product_id,
        },

        success: function(response) {

            $("#add_modal").html(response);


        },

    });


    $("#view-modal").modal('show');

}



function view_modal(product_id) {

    var product_id = product_id;

    $.ajax({
        url: "assets/ajax/product_carousel_load.php",
        type: "POST",

        data: {
            product_id: product_id,
        },

        success: function(response) {

            $("#view_modal_data").html(response);


        },

    });

    $("#view-modal").modal('show');
}


function edit_modal(id) {

    document.getElementById("product_id").value = id;

    $.ajax({
        url: "assets/ajax/product_select_edit.php",
        type: "POST",

        data: {
            product_id: id,
        },

        success: function(response) {

            $(".edit_content_div").html(response);


        },

    });



    $("#add_select_category").select2({

        placeholder: 'Please Select a Category'
    });


    $("#edit-modal").modal('show');

}

function show_sub_category_edit() {
    var product_id = document.getElementById('categories_edit').value;
    $.ajax({
        url: "assets/ajax/show_sub_category_edit.php",
        type: "POST",
        data: {
            product_id: product_id,
        },
        success: function(response) {
            $("#show_sub_category_div").html(response);
        },
    });
}


function delete_modal(id) {

    document.getElementById('delete_product_id').value = id;
    $("#delete-modal").modal('show');
}
</script>




<script>
const urlParams = new URLSearchParams(window.location.search);


if (urlParams.get('status') === '1') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4>Product Added</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Added</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}

if (urlParams.get('status') === '2') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Product Deleted</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Deleted</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
if (urlParams.get('status') === '3') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Product Updated</h4><p class="text-muted mx-4 mb-0">Product Have Been Successfully Updated</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
</script>
</body>

</html>