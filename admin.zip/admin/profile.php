<?php include('header.php');

$email = $_SESSION['admin_email'];
$query = "SELECT * from countries";
$countries = db::getRecords($query);

$query = "SELECT * from admins where  email='$email'";
$admin = db::getRecord($query);
$first_name = $admin['first_name'];
$last_name = $admin['last_name'];
$phone = $admin['phone'];
$city = $admin['city'];
$gender = $admin['gender'];
$admin_country = $admin['country'];
$profile_image = $admin['image_name'];

?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <div class="profile-foreground position-relative mx-n4 mt-n4">
                <div class="profile-wid-bg">
                    <img src="assets/images/profile-bg.jpg" alt="" class="profile-wid-img" />

                </div>
            </div>
            <div class="pt-4 mb-4 mb-lg-3 pb-lg-4 profile-wrapper">
                <div class="row g-4 my-5">
                    <h2 class="text-center fs-1 text-white">Profile Details</h2>

                </div>
                <!--end row-->
            </div>

            <div class="pt-4 mb-4 mb-lg-3 pb-lg-4 profile-wrapper">
                <div class="row mt-5">

                    <!--end col-->
                    <div class="col-sm-10 offset-sm-1">
                        <div class="card mt-xxl-n5">
                            <div class="card-header">
                                <ul class="nav nav-tabs-custom rounded card-header-tabs border-bottom-0" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link text-body active" data-bs-toggle="tab"
                                            href="#personalDetails" role="tab">
                                            <i class="fas fa-home"></i>
                                            Personal Details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-body" data-bs-toggle="tab" href="#changePassword"
                                            role="tab">
                                            <i class="fas fa-user-edit"></i> Edit Details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-body" data-bs-toggle="tab" href="#experience"
                                            role="tab">
                                            <i class="fas fa-lock"></i> Change Password
                                        </a>
                                    </li>

                                </ul>
                            </div>
                            <div class="card-body p-4">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="personalDetails" role="tabpanel">
                                        <div class="row">
                                            <div
                                                class="col-md-4 col-sm-12 d-flex justify-content-sm-center align-items-sm-center ">
                                                <div class="avatar-xl my-4">
                                                    <img src="./uploads/profile/<?php echo $profile_image ?>"
                                                        alt="user-img" class="img-thumbnail rounded-circle avatar-xl">
                                                </div>

                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="heading">
                                                    <h2>First Name:</h2>
                                                </div>
                                                <div class="para  ">
                                                    <h4>
                                                        <?php echo $first_name; ?>
                                                    </h4>
                                                </div>

                                                <div class="heading  my-4">
                                                    <h2>Last Name:</h2>
                                                </div>
                                                <div class="para  ">
                                                    <h4>
                                                        <?php echo $last_name; ?>
                                                    </h4>
                                                </div>
                                                <div class="heading  my-4">
                                                    <h2>Country:</h2>
                                                </div>
                                                <div class="para  ">
                                                    <h4>
                                                        <?php echo $admin_country; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="heading my-4">
                                                    <h2>Phone:</h2>
                                                </div>
                                                <div class="para  ">
                                                    <h4>
                                                        <?php echo $phone; ?>
                                                    </h4>
                                                </div>

                                                <div class="heading  my-4">
                                                    <h2>Email:</h2>
                                                </div>
                                                <div class="para  ">
                                                    <h4>
                                                        <?php echo $email ?>
                                                    </h4>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!--end tab-pane-->
                                    <div class="tab-pane" id="changePassword" role="tabpanel">
                                        <form action="action.php" enctype="multipart/form-data" method="post">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="firstnameInput" class="form-label">First
                                                            Name</label>
                                                        <input type="text" name="fname"
                                                            value="<?php echo $first_name; ?>" class="form-control"
                                                            id="firstnameInput" name="first_name"
                                                            placeholder="Enter your firstname">
                                                    </div>
                                                </div>
                                                <!--end col-->
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="lastnameInput" class="form-label">Last
                                                            Name</label>
                                                        <input type="text" name="lname" class="form-control"
                                                            value="<?php echo $last_name; ?>" id="lastnameInput"
                                                            name="last_name" placeholder="Enter your lastname"
                                                            value="Adame">
                                                    </div>
                                                </div>
                                                <!--end col-->
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="phonenumberInput" class="form-label">Phone
                                                            Number</label>
                                                        <div class="form-icon">
                                                            <input type="tel" name="phone"
                                                                value="<?php echo $phone; ?>"
                                                                class="form-control form-control-icon" id="iconInput"
                                                                placeholder="Enter Your Phone Number">
                                                            <i class="ri-phone-fill"></i>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="email" class="form-label">Email</label>
                                                        <div class="form-icon">
                                                            <input type="email" name="email"
                                                                value="<?php echo $email; ?>"
                                                                class="form-control form-control-icon" id="iconInput"
                                                                placeholder="Enter Your Email">
                                                            <i class="ri-mail-fill"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label for="countries" class="lead">Select a Country</label>
                                                        <select class="form-control form-select"
                                                            data-placeholder="Select Country" name="country"
                                                            id="countries">
                                                            <option></option>
                                                            <?php foreach ($countries as $country) {
                                                                ?>
                                                                <option value="<?php echo $country['name'] ?>" <?php if ($country['name'] == $admin['country']) {
                                                                       echo 'selected';
                                                                   } ?>><?php echo $country['name'] ?></option>
                                                            <?php } ?>

                                                        </select>

                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <div>
                                                            <label for="formSizeDefault" class="form-label">Upload your
                                                                file</label>

                                                            <input class="form-control" id="formSizeDefault" type="file"
                                                                name="admin_profile">
                                                        </div>

                                                    </div>
                                                </div>


                                                <div class="mt-4">
                                                    <button type="submit" class="btn btn-success w-20 text-center"
                                                        name="update_details" type="submit">Update Details</button>
                                                </div>
                                            </div>
                                            <!--end row-->
                                        </form>

                                    </div>
                                    <!--end tab-pane-->
                                    <div class="tab-pane" id="experience" role="tabpanel">
                                        <form action="action.php" method="post">

                                            <div class="row ">
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="password-input">Old
                                                            Password</label>
                                                        <div class="position-relative auth-pass-inputgroup">
                                                            <input type="password"
                                                                title="Minimum 8
                                                            characters, One lowercase letter ,One Uppercase letter and at least one number"
                                                                class="form-control pe-5 password-input"
                                                                name="old_password" onpaste="return false"
                                                                placeholder="Enter password" id="password-input"
                                                                aria-describedby="passwordInput"
                                                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>
                                                            <button
                                                                class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon"
                                                                type="button" id="password-addon"><i
                                                                    class="ri-eye-fill align-middle"></i></button>
                                                        </div>
                                                        <div id="passwordInput" class="form-text">Must be at least 8
                                                            characters.</div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="confirm-password-input">New
                                                            Password</label>
                                                        <div class="position-relative auth-pass-inputgroup mb-3">
                                                            <input type="password"
                                                                title="Minimum 8
                                                            characters, One lowercase letter ,One Uppercase letter and at least one number"
                                                                class="form-control pe-5 password-input"
                                                                name="new_password" onpaste="return false"
                                                                placeholder="Confirm password"
                                                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                                                id="confirm-password-input" required>
                                                            <button
                                                                class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon"
                                                                type="button" id="confirm-password-input"><i
                                                                    class="ri-eye-fill align-middle"></i></button>
                                                        </div>
                                                    </div>

                                                </div>



                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="confirm-password-input">Confirm
                                                            Password</label>
                                                        <div class="position-relative auth-pass-inputgroup mb-3">
                                                            <input type="password"
                                                                title="Minimum 8
                                                            characters, One lowercase letter ,One Uppercase letter and at least one number"
                                                                class="form-control pe-5 password-input"
                                                                name="confirm_new_password" onpaste="return false"
                                                                placeholder="Confirm password"
                                                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                                                id="confirm-password-input" required>
                                                            <button
                                                                class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon"
                                                                type="button" id="confirm-password-input"><i
                                                                    class="ri-eye-fill align-middle"></i></button>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="mt-4">
                                                    <input type="hidden" name="id"
                                                        value="<?php echo $_SESSION['admin_email'] ?>">
                                                    <button type="submit" name="change_password"
                                                        class="btn btn-success w-20 text-center">Change
                                                        Password</button>
                                                </div>
                                        </form>
                                    </div>
                                </div>
                                <!--end tab-pane-->

                            </div>
                        </div>
                    </div>
                </div>
                <!--end col-->
            </div>
        </div>
        <!--end row-->

    </div><!-- container-fluid -->
</div><!-- End Page-content -->


</div><!-- end main content-->

</div>
<!-- END layout-wrapper -->


<!--start back-to-top-->
<button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
    <i class="ri-arrow-up-line"></i>
</button>
<!--end back-to-top-->

<!--preloader-->
<div id="preloader">
    <div id="status">
        <div class="spinner-border text-primary avatar-sm" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</div>


<!-- JAVASCRIPT -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/feather-icons/feather.min.js"></script>
<script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>

<!-- apexcharts -->
<script src="assets/libs/apexcharts/apexcharts.min.js"></script>

<!-- Vector map-->
<script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
<script src="assets/libs/jsvectormap/maps/world-merc.js"></script>

<!--Swiper slider js-->
<script src="assets/libs/swiper/swiper-bundle.min.js"></script>

<!-- Dashboard init -->
<script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
<script src="assets/js/pages/password-addon.init.js"></script>


<!-- App js -->
<script src="assets/js/app.js"></script>

<script>
    function format(item, state) {
        if (!item.id) {
            return item.text;
        }
        var countryUrl = "";
        var stateUrl = "";
        var url = state ? stateUrl : countryUrl;
        var img = $("<>", {
            class: "img-flag",
            width: 26,
            src: url + item.element.value.toLowerCase() + ".svg"
        });
        var span = $("<span>", {
            text: " " + item.text
        });
        span.prepend(img);
        return span;
    }

    $(document).ready(function () {
        $("#countries").select2({
            templateResult: function (item) {
                return format(item, false);
            }
        });

    });
    $(document).ready(function () {
        $("#cities").select2({
            templateResult: function (item) {
                return format(item, false);
            }
        });

    });
</script>
</body>

</html>