<?php include('header.php');

session_start();

require_once('database.php');





$db = db::open();
$query = "SELECT *  from sub_categories";
$sub_categories = db::getRecords($query);

$db = db::open();
$query = "SELECT *  from categories";
$categories = db::getRecords($query);

?>

<div class='main-content'>
    <div class='page-content'>
        <div class='container-fluid'>
            <div class="row mt-1 mb-4">
                <div class="col-12">
                    <div class="py-5  d-sm-flex flex-column align-items-center justify-content-center custom-gradient">
                        <h3 class="text-center text-white my-2">Sub Categories</h3>
                    </div>
                </div>
            </div>
            <!--end row-->
            <div class="row">
                <div class="col-12 px-n2">
                    <div class="bg-white px-3 py-3 d-sm-flex align-items-center justify-content-between">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">Sub Categories</li>
                        </ol>
                        <div class="page-title-right">
                            <button type='button' class='btn custom-gradient  text-white  fs-7 ' data-bs-toggle='modal'
                                data-bs-target='#add_sub_category'>Add Sub Category</button>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">
                            <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12" id="show_table">
                                    <table id="fixed-header"
                                        class="table table-bordered dt-responsive nowrap table-striped align-middle dataTable no-footer dtr-inline"
                                        style="width: 100%;" aria-describedby="fixed-header_info">
                                        <thead>

                                            <tr>

                                                <th class="sorting fw-bolder" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 83.6px;"
                                                    aria-label="SR No.: activate to sort column ascending">SR No.</th>
                                                <th class="sorting fw-bolder" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 71.6px;"
                                                    aria-label="ID: activate to sort column ascending">Category Title</th>
                                                <th class="sorting fw-bolder" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 71.6px;"
                                                    aria-label="ID: activate to sort column ascending">Sub Category Title</th>


                                                <th class="sorting fw-bolder" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" style="width: 85.6px;"
                                                    aria-label="Action: activate to sort column ascending">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            if (!empty($sub_categories)) {

                                                foreach ($sub_categories as $key => $sub_category) { 
                                                    $key = $key + 1;            
                                                    $category_id = $sub_category['category_id'];                       
                                                    $query = "SELECT *  from categories WHERE id ='$category_id'";
                                                    $category = db::getRecord($query);     ?>
                                            <tr class="odd">

                                                <td>
                                                    <?php echo $key ; ?>
                                                </td>
                                                <td>
                                                    <?php echo $category['title'];?>
                                                </td>
                                                <td>
                                                    <?php echo $sub_category['title'];?>
                                                </td>


                                                <td>

                                                    <div class="dropdown">
                                                        <button class="btn btn-soft-secondary btn-sm dropdown"
                                                            type="button" data-bs-toggle="dropdown"
                                                            aria-expanded="false">
                                                            <i class="ri-more-fill align-middle"></i>
                                                            &nbsp;Actions
                                                        </button>
                                                        <ul class="dropdown-menu dropdown-menu-center">
                                                            <div
                                                                class="d-flex justify-content-start align-items-center ms-2  ">
                                                                <i class='fas fa-eye '></i>
                                                                <p type='button' class='ps-2 py-1'
                                                                    onclick="view_modal('<?php echo $sub_category['title']; ?>','<?php echo $category['title']; ?>')">
                                                                    View Details</p>

                                                            </div>
                                                            <li>

                                                                <div
                                                                    class="d-flex justify-content-start align-items-center ms-2 ">
                                                                    <i class='fas fa-pen'> </i>
                                                                    <p type='button' class='ps-2 py-1'
                                                                        onclick="edit_modal('<?php echo $sub_category['id']; ?>','<?php echo $sub_category['category_id']; ?>','<?php echo $sub_category['title']; ?>')">
                                                                        Edit Details</p>
                                                                </div>

                                                            </li>

                                                            <div
                                                                class="d-flex justify-content-start align-items-center ms-2">
                                                                <i class='fas fa-trash me-2'></i>
                                                                <p type='button' class='ps-2 py-1'
                                                                    onclick="delete_modal('<?php echo $sub_category['id']; ?>')">
                                                                    Delete Category</p>
                                                            </div>


                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php }
                                            } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>

        </div>
    </div>
</div>

<div id='add_sub_category' class='modal fade' aria-labelledby='add_sub_category' aria-hidden='true'
    style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-primary '>
                <h2 class='text-white'>Add Sub Category </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <form action='action.php' enctype="multipart/form-data" method='post'>
                    <div class="heading my-3">
                        <div class="mb-3">
                            <label for="sub_ategory" class="lead">Category</label>
                            <select class="select2-selection select2-selection--single form-control"
                                name="sub_category_id" id="add_sub_category_select">
                                <?php foreach ($categories as $category) { ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['title']; ?>
                                </option>
                                <?php } ?>
                            </select>

                        </div>
                    </div>

                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <label for='sub_category' class='form-label fs-4  '>Sub Category Title</label>
                            <input type='text' class='form-control' name='sub_category_title' id='text'
                                placeholder='Enter Sub Category title' required>
                        </div>
                    </div>

                    <button type='submit' name='add_sub_category' class='btn btn-primary waves-effect waves-light '>Add
                        Category</button>
                </form>


            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

</div>



<div id='view-modal' class='modal fade' aria-labelledby='view-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0 border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-primary '>
                <h2 class='text-white'>View Details</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <div class='heading my-3'>
                    <h3 class='my-3'>Category Title</h3>
                    <p id="view_sub_category_title" class='mt-2 fs-5  text-dark'></p>
                </div>
                <div class='heading my-3'>
                    <h3 class='my-3'> Sub Category Title</h3>
                    <p id="view_catedgory_title" class='mt-2 fs-5  text-dark'></p>
                </div>



                <div class="heading my-3 float-end">
                    <button type="button" data-bs-dismiss="modal"
                        class="btn btn-light waves-effect waves-light btn-lg btn-block">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>




</div>
<div id='edit-modal' class='modal fade' aria-labelledby='edit-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0'>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-success '>
                <h2 class='text-white'>Edit Details</h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-body py-3 px-5'>
                <form action='action.php' enctype="multipart/form-data" method='post'>
                    <div class="heading my-3">
                        <div id="select_data"></div>
                    </div>
                    <div class='heading my-3'>
                        <div class='mb-3'>
                            <label for='update_sub_category_title' class='form-label fs-4  '>Sub Category Title</label>
                            <input type='text' class='form-control' name='title' id='update_sub_category_title'
                                required>
                        </div>
                    </div>

                    <input type="hidden" name="update_category_id" id="update_category_id">
                    <input type="hidden" name="id" id="update_sub_category_id" >
                    <button type='submit' name='update_sub_category'
                        class='btn btn-success waves-effect waves-light '>Update Category</button>
                </form>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
</div>

<div id='delete-modal' class='modal fade' aria-labelledby='delete-modal' aria-hidden='true' style='display: none;'>
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content border-0 '>
            <div class='close d-flex justify-content-between align-items-center  px-4 py-3 bg-danger '>
                <h2 class='text-white'>Delete </h2>
                <button type='button' class='btn-close btn-close-white mt-n2 opacity-100' data-bs-dismiss='modal'
                    aria-label='Close'></button>
            </div>
            <div class=' modal-header'>

            </div>
            <div class='modal-body py-3 px-5'>
                <div class='mt-3 text-center'>
                    <lord-icon src='https://cdn.lordicon.com/gsqxdxog.json' trigger='loop'
                        colors='primary:#f7b84b,secondary:#f06548' style='width:100px;height:100px'></lord-icon>
                    <div class='mt-4 pt-2 fs-15 mx-5'>
                        <h4>Are you Sure ?</h4>
                        <p class='text-muted mx-4 mb-0'>Are you Sure You want to Delete this Sub Category ?</p>
                        <form action="action.php" method="post">
                            <div class='btn d-flex justify-content-center gap-3 py-4'>
                                <input id="delete_sub_category_id" type="hidden" name="sub_category_id">
                                <button type='submit' name="delete_sub_category"
                                    class='btn btn-danger w-lg bg-gradient waves-effect waves-light'>Yes Delete
                                    It</button>
                                <button type='button' data-bs-dismiss='modal'
                                    class='btn btn-primary w-lg bg-gradient waves-effect waves-light'>Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>
</div>
</div>














 <!--start back-to-top-->
 <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <footer class="footer ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <p>&copy; Copyright
                        <script>
                        document.write(new Date().getFullYear());
                        </script> Single Solution.
                    </p>
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        <p> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- end main content-->







<!-- JAVASCRIPT -->
<script src='assets/libs/bootstrap/js/bootstrap.bundle.min.js'></script>
<script src='assets/libs/simplebar/simplebar.min.js'></script>
<script src='assets/libs/node-waves/waves.min.js'></script>
<script src='assets/libs/feather-icons/feather.min.js'></script>
<script src='assets/js/pages/plugins/lord-icon-2.1.0.js'></script>
<script src='assets/js/plugins.js'></script>
<!-- Sweet Alerts js -->
<script src='assets/libs/sweetalert2/sweetalert2.min.js'></script>

<!-- Sweet alert init js-->
<script src='assets/js/pages/sweetalerts.init.js'></script>
<!-- calendar min js -->
<script src='assets/libs/fullcalendar/main.min.js'></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!-- Calendar init -->
<script src='assets/js/pages/calendar.init.js'></script>
<script src="./assets/js/pages/jquery.dataTables.min.js"></script>
<script src="./assets/js/pages/dataTables.bootstrap5.min.js"></script>
<script src="./assets/js/pages/dataTables.responsive.min.js"></script>
<script src="./assets/js/pages/dataTables.buttons.min.js"></script>
<script src="./assets/js/pages/buttons.print.min.js"></script>
<script src="./assets/js/pages/buttons.html5.min.js"></script>
<script src="./assets/js/pages/vfs_fonts.js"></script>
<script src="./assets/js/pages/pdfmake.min.js"></script>
<script src="./assets/js/pages/jszip.min.js"></script>
<script src="./assets/js/pages/datatables.init.js"></script>
<!-- App js -->
<script src='assets/js/app.js'></script>
<script>
    // Empty Table Text
    function changeText() {
        var hide_data = document.querySelector('.dataTables_empty');
        if (hide_data) {
            hide_data.textContent = 'No Sub Categories are available';
        }
    }

    var observer = new MutationObserver(function (mutationsList) {
        for (var mutation of mutationsList) {
            if (mutation.addedNodes.length > 0) {
                changeText();
                break;
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    window.onload = function () {
        changeText(); // Run the function once in case the element is already present
    };
 </script>
<script>
// Fucntion For Modals

function view_modal(title, category_title) {
    document.getElementById('view_sub_category_title').innerHTML = category_title;
    document.getElementById('view_catedgory_title').innerHTML = title;
    $("#view-modal").modal('show');
}

function edit_modal(id,category_id, title) {
    document.getElementById('update_sub_category_id').value = id;
    document.getElementById('update_category_id').value = category_id;
    document.getElementById('update_sub_category_title').value = title;



    $.ajax({
        url: "./assets/ajax/sub_category.php",
        type: "POST",

        data: {
            category_id: category_id
        },

        success: function(response) {
            $("#select_data").html(response);
        },

    });
    $("#edit-modal").modal('show');
}

function delete_modal(id) {
    document.getElementById('delete_sub_category_id').value = id;
    $("#delete-modal").modal('show');
}

$("#add_sub_category_select").select2({

    placeholder: 'Please Select a sub_Category',
    dropdownParent: $('#add_sub_category .modal-content')
});
$("#sub_category").select2({

    placeholder: 'Please Select a sub_Category',
    dropdownParent: $('#add_sub_category .modal-content')
});
</script>
<script>
const urlParams = new URLSearchParams(window.location.search);


if (urlParams.get('status') === '1') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"><lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></lord-icon><div class="mt-4 pt-2 fs-15"><h4SubCategory Added</h4><p class="text-muted mx-4 mb-0">Sub Category Have Been Successfully Added</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 btn-success",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}

if (urlParams.get('status') === '2') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Sub Category Deleted</h4><p class="text-muted mx-4 mb-0">Sub Category Have Been Successfully Deleted</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
if (urlParams.get('status') === '3') {
    // Show the Swal alert
    Swal.fire({
        html: '<div class="mt-3"></div><img src="https://nutpinsurance.com/images/success.gif" trigger="loop" colors="primary:#13c56b,secondary:#08a88a" style="width:120px;height:120px"></img><div class="mt-4 pt-2 fs-15"><h4>Sub Category Updated</h4><p class="text-muted mx-4 mb-0">Sub Category Have Been Successfully Updated</p></div></div>',
        showCancelButton: !0,
        showConfirmButton: !1,
        cancelButtonClass: "btn text-white  w-xs mb-1 bg-ban",
        cancelButtonText: "Close",
        buttonsStyling: !1,
        showCloseButton: !0,
    }).then((result) => {
        if (result.isConfirmed) {
            // User clicked the "confirm" button, so update the URL and prevent the Swal from firing again
            history.pushState({}, '', window.location.pathname);
        } else {
            history.pushState({}, '', window.location.pathname);
        }
    });
}
</script>
</body>

</html>