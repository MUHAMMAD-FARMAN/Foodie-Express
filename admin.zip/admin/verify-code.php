<?php
session_start();
require_once("database.php");


$db = db::open();
$email = $_GET['email'];
$code = isset($_GET['code']) ? $_GET['code'] : '';


$query = "SELECT * from verify_code where email='$email' ORDER by id DESC";
$verification = db::getRecord($query);

if ($verification['code'] == $code) {

    $db = db::open();
    $query = "DELETE from verify_code WHERE email = '$email'  ORDER by id DESC";
    $delete_code = db::query($query);
    if ($delete_code) {
        $status = 7;
        header("Location: https://dev.single-solution.com/shabo_v11/login.php?status=$status");
    }
}

?>

<!DOCTYPE html>
<html lang="en" data-layout="horizontal" data-topbar="dark" data-sidebar-size="lg" data-sidebar="light"
    data-sidebar-image="none" data-preloader="disable">

<head>
    <meta charset="utf-8" />
    <title>Admin | Verify Code</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="auth-page-wrapper pt-5">
        <!-- auth page bg -->
        <div class="auth-one-bg-position auth-one-bg" style="background-image: url(./assets/images/bread.jpg);" id="auth-particles">
            <div class="bg-overlay"></div>
            <div class="shape">
                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink"
                    viewBox="0 0 1440 120">
                    <path d="M 0,36 C 144,53.6 432,123.2 720,124 C 1008,124.8 1296,56.8 1440,40L1440 140L0 140z"></path>
                </svg>
            </div>
        </div>

        <!-- auth page content -->
        <div class="auth-page-content">
            <div class="container">
                <!-- end row -->

                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card mt-4">
                            <div class="card-body p-4">
                                <div class="text-center mt-2">

                                
                                <?php 

                                    $db = db::open();
                                    $query = "DELETE from verify_code WHERE email = '$email'  ORDER by id DESC";
                                    $delete_code = db::query($query); 
                                    if(!$delete_code) {
                                    ?>

                                    <div class="text-center mt-2">
                                        <h5 class="text-primary fs-4 fw-bolder">
                                            Code Expired
                                        </h5>
                                    </div>

                                    <div class="p-2">
                                        <div class="alert alert-borderless alert-warning text-center mb-2 mx-2 fs-6"
                                            role="alert">
                                            A Verification Code Has Been Expired For the
                                            <u>
                                                <?php echo $email ?>
                                            </u> Please Try to Send New Code
                                        </div>
                                    </div>
                                <?php } else { ?>
                                    <h5 class="text-primary">Verification Code</h5>

                                    <lord-icon src="https://cdn.lordicon.com/rhvddzym.json" trigger="loop"
                                        colors="primary:#0ab39c" class="avatar-xl">
                                    </lord-icon>
                                </div>

                                <div class="alert alert-borderless alert-warning text-center mb-2 mx-2" role="alert">
                                    A 6 digit Verification Code has been sent to you Email
                                </div>

                                    <div class="p-2">
                                        <form action="action.php" method="post">
                                            <div class="mb-4">
                                                <label class="form-label">Verification Code</label>
                                                <input type="tel" name="code" maxlength="6" value="" class="form-control"
                                                    id="email" placeholder="Enter Recovery Code" />
                                            </div>

                                            <div class="text-center mt-4">
                                                <input type="hidden" name="email" value="<?php echo $email; ?>" />
                                                <button name="verify_code" class="btn btn-success w-100" type="submit">
                                                    Recover Account
                                                </button>
                                            </div>
                                        </form>
                                        <!-- end form -->
                                    </div>
                                </div>
                                <!-- end card body -->
                            </div>
                            <!-- end card -->

                        <?php } ?>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end auth page content -->

        <!-- footer -->

        <!-- end Footer -->
    </div>
    <!-- end auth-page-wrapper -->

    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- particles js -->
    <script src="assets/libs/particles.js/particles.js"></script>
    <!-- particles app js -->
    <script src="assets/js/pages/particles.app.js"></script>
    <!-- password-addon init -->
    <script src="assets/js/pages/password-addon.init.js"></script>
</body>

</html>